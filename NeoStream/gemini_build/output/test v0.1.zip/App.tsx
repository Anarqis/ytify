
import React, { useState, useRef, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import MobileNav from './components/MobileNav';
import PlayerBar from './components/PlayerBar';
import VideoOverlay from './components/VideoOverlay';
import AIDJView from './components/AIDJView';
import ProfileView from './components/ProfileView';
import SearchView from './components/SearchView';
import LibraryView from './components/LibraryView';
import LikedSongsView from './components/LikedSongsView';
import { Song, ViewMode, PlaybackState } from './types';
import { MOCK_SONGS, TRENDING_PLAYLISTS } from './constants';
import { Play, Heart, Sparkles, BarChart3 } from './components/Icon';
import { Logo } from './components/Logo';

function App() {
  const [currentView, setCurrentView] = useState<ViewMode>(ViewMode.HOME);
  const [currentSong, setCurrentSong] = useState<Song | null>(MOCK_SONGS[0]);
  const [playbackState, setPlaybackState] = useState<PlaybackState>(PlaybackState.PAUSED);
  const [isVideoMode, setIsVideoMode] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  // New state for Vibe Selection
  const [selectedVibe, setSelectedVibe] = useState('Cyberpunk');

  // New state for Video Panel and Header Visibility
  const [isVideoPanelOpen, setIsVideoPanelOpen] = useState(true);
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);
  const lastScrollY = useRef(0);
  
  // Ref for horizontal scrolling of Vibe list
  const vibeScrollRef = useRef<HTMLDivElement>(null);

  // EFFECT: Handle Vibe Wheel Scroll without page scrolling
  useEffect(() => {
    const element = vibeScrollRef.current;
    if (element) {
      const onWheel = (e: WheelEvent) => {
        if (e.deltaY !== 0) {
          e.preventDefault(); // This stops the main page from scrolling
          element.scrollLeft += e.deltaY;
        }
      };
      // Use non-passive listener to allow preventDefault
      element.addEventListener('wheel', onWheel, { passive: false });
      return () => element.removeEventListener('wheel', onWheel);
    }
  }, []);

  const handlePlaySong = (song: Song) => {
    if (currentSong?.id === song.id) {
        setPlaybackState(prev => prev === PlaybackState.PLAYING ? PlaybackState.PAUSED : PlaybackState.PLAYING);
    } else {
        setCurrentSong(song);
        setPlaybackState(PlaybackState.PLAYING);
    }
  };

  const handleTogglePlay = () => {
    setPlaybackState(prev => prev === PlaybackState.PLAYING ? PlaybackState.PAUSED : PlaybackState.PLAYING);
  };

  const handleToggleVideo = () => {
    setIsVideoMode(prev => {
      const enteringVideo = !prev;
      if (enteringVideo) {
        setIsSidebarCollapsed(true);
        setIsVideoPanelOpen(false);
      }
      return enteringVideo;
    });
  };

  const handleViewChange = (view: ViewMode) => {
      setCurrentView(view);
      setIsVideoMode(false);
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const currentScrollY = e.currentTarget.scrollTop;
    if (Math.abs(currentScrollY - lastScrollY.current) > 10) {
        if (currentScrollY > 50 && currentScrollY > lastScrollY.current) {
             setIsHeaderVisible(false);
        } else {
             setIsHeaderVisible(true);
        }
    }
    lastScrollY.current = currentScrollY;
    setIsScrolled(currentScrollY > 50);
  };

  const VIBES = ['Focus', 'Cyberpunk', 'Rain', 'Neon', 'Drive', 'Night', 'Code', 'Deep'];

  const getVibeSongs = () => {
      const shift = Math.max(0, VIBES.indexOf(selectedVibe));
      const rotated = [...MOCK_SONGS.slice(shift % MOCK_SONGS.length), ...MOCK_SONGS.slice(0, shift % MOCK_SONGS.length)];
      return rotated.slice(0, 4);
  };

  const renderHome = () => (
    <div className="space-y-8 md:space-y-12 pb-48 pt-0">
        <div className="relative w-full h-[65vh] md:h-[75vh] min-h-[500px] flex flex-col justify-end pb-4 transition-all duration-700">
            <div className="absolute inset-0 z-0">
                <img 
                    src="https://picsum.photos/1200/800?random=99" 
                    alt="Hero Background" 
                    className="w-full h-full object-cover opacity-80 mask-image-gradient"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/40 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-r from-[#09090b]/60 via-transparent to-transparent" />
            </div>

            <div className="relative z-10 px-6 md:px-12 max-w-4xl animate-in slide-in-from-bottom-10 duration-700 fade-in pb-2 md:pb-0">
                {/* Clickable Hero Title - Added w-fit to fix click area */}
                <h1 
                    onClick={() => handlePlaySong(MOCK_SONGS[0])}
                    className="w-fit text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-black mb-3 leading-[0.9] tracking-tighter text-white font-syne drop-shadow-xl cursor-pointer hover:text-fuchsia-300 transition-colors active:scale-[0.99] origin-left"
                >
                    Cybernetic <br /> Dreams
                </h1>

                {/* Badge Adjustment: Restored padding, moved closer to title */}
                <div className="flex items-center gap-3 mb-6">
                     <div className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-fuchsia-500 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-fuchsia-500 shadow-[0_0_15px_#d946ef]"></span>
                    </div>
                     <div className="px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
                        <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-[0.2em] font-syne">
                            Featured Premiere
                        </span>
                     </div>
                </div>
                
                <p className="text-zinc-200 text-lg md:text-2xl max-w-2xl mb-8 font-light leading-snug drop-shadow-lg">
                    Dive into the neon-soaked streets of the future. A sonic journey curated by neural networks for the ultimate focus state.
                </p>
                
                <div className="flex items-center gap-4 mb-6">
                    <button 
                        onClick={() => handlePlaySong(MOCK_SONGS[0])}
                        className="h-10 md:h-14 px-6 md:px-10 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-xl text-white font-bold text-sm md:text-lg hover:scale-105 active:scale-95 transition-all shadow-[0_0_40px_rgba(255,255,255,0.1)] flex items-center gap-2 md:gap-3 group border-none"
                    >
                        <Play className="w-4 h-4 md:w-5 md:h-5 fill-white" /> Play Now
                    </button>
                    <button className="h-10 w-10 md:h-14 md:w-14 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-xl flex items-center justify-center transition-colors text-white active:scale-95 border-none shadow-lg">
                        <Heart className="w-5 h-5 md:w-6 md:h-6" />
                    </button>
                </div>

                <div className="w-full">
                     <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-3 flex items-center gap-2 opacity-80">
                        <Sparkles className="w-3 h-3 text-fuchsia-400" /> Current Vibe
                     </p>
                     
                     {/* Ref attached for custom wheel handling */}
                     <div 
                        ref={vibeScrollRef}
                        className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide mask-image-gradient-r -mx-1 px-1 cursor-grab active:cursor-grabbing"
                     >
                        {VIBES.map((tag) => (
                          <button 
                            key={tag}
                            onClick={() => setSelectedVibe(tag)}
                            className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest backdrop-blur-md whitespace-nowrap transition-all hover:scale-105 active:scale-95 border border-transparent
                            ${selectedVibe === tag 
                                ? 'bg-fuchsia-600/30 text-white shadow-[0_0_15px_rgba(217,70,239,0.3)]' 
                                : 'bg-white/5 hover:bg-white/10 text-zinc-300'}`}
                          >
                            {tag}
                          </button>
                        ))}
                    </div>

                    {/* Updated Tile Design with details below */}
                    <div className="flex gap-4 overflow-hidden mt-2 pb-2">
                        {getVibeSongs().map((song) => (
                            <div 
                                key={`vibe-${song.id}-${selectedVibe}`}
                                onClick={() => handlePlaySong(song)}
                                className="group/vibe flex flex-col gap-2 cursor-pointer w-32 md:w-36 shrink-0"
                            >
                                {/* Image Container */}
                                <div className="relative w-full h-20 rounded-xl overflow-hidden border border-white/5 group-hover/vibe:border-fuchsia-500/50 transition-all group-hover/vibe:scale-[1.02]">
                                    <img src={song.coverUrl} className="w-full h-full object-cover" alt={song.title} />
                                    <div className="absolute inset-0 bg-black/20 group-hover/vibe:bg-black/40 transition-colors duration-300" />
                                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/vibe:opacity-100 transition-opacity duration-300">
                                        <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
                                             <Play className="w-3.5 h-3.5 fill-white text-white ml-0.5" />
                                        </div>
                                    </div>
                                </div>
                                
                                {/* Info Container */}
                                <div className="flex flex-col gap-0.5 px-0.5">
                                    <span className="font-bold text-white text-xs truncate leading-tight group-hover/vibe:text-fuchsia-400 transition-colors">{song.title}</span>
                                    <span className="text-[10px] text-zinc-400 truncate">{song.artist}</span>
                                    <div className="flex items-center gap-1.5 mt-0.5">
                                        <span className="text-[9px] text-zinc-500 font-medium">{song.views || '0'} views</span>
                                        <span className="w-0.5 h-0.5 rounded-full bg-zinc-600"></span>
                                        <span className="text-[9px] text-zinc-500 font-medium">{song.publishedAt || 'Now'}</span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>

        {/* Sonic Stream Section - Significantly increased negative margin for pull-up effect */}
        <section className="px-6 md:px-12 relative z-20 -mt-32 md:-mt-52 pointer-events-none">
            <div className="flex items-end justify-between mb-4 md:mb-6 pointer-events-auto">
                <div>
                    <h3 className="text-xl md:text-2xl font-bold tracking-tight text-white mb-1 font-syne drop-shadow-md">Sonic Stream</h3>
                    <p className="text-xs md:text-sm text-zinc-400 drop-shadow-md">Flowing tracks based on your vibe</p>
                </div>
            </div>

            {/* Restored tile width for desktop (md:w-[240px]) */}
            <div className="flex gap-4 overflow-x-auto pb-4 md:pb-8 snap-x snap-mandatory scrollbar-hide pointer-events-auto">
                {MOCK_SONGS.map((song) => (
                    <div 
                        key={song.id} 
                        onClick={() => handlePlaySong(song)}
                        className="snap-start shrink-0 w-[140px] md:w-[240px] relative aspect-[3/4] rounded-2xl overflow-hidden group cursor-pointer border border-white/5 shadow-2xl bg-zinc-900 active:scale-95 transition-transform"
                    >
                        <img 
                            src={song.coverUrl} 
                            alt={song.title} 
                            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-hover:rotate-1" 
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
                        
                        {currentSong?.id === song.id && playbackState === PlaybackState.PLAYING && (
                            <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] flex items-center justify-center">
                                <div className="flex gap-1 h-6 md:h-8 items-end">
                                    <div className="w-1 md:w-1.5 bg-fuchsia-500 animate-[bounce_1s_infinite]"></div>
                                    <div className="w-1 md:w-1.5 bg-fuchsia-400 animate-[bounce_1.2s_infinite]"></div>
                                    <div className="w-1 md:w-1.5 bg-fuchsia-600 animate-[bounce_0.8s_infinite]"></div>
                                </div>
                            </div>
                        )}

                        <div className="absolute bottom-0 left-0 right-0 p-4 md:p-5 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                            {/* Compacted Typography */}
                            <h4 className={`font-bold text-base md:text-lg leading-tight mb-0 truncate ${currentSong?.id === song.id ? 'text-fuchsia-400' : 'text-white'}`}>
                                {song.title}
                            </h4>
                            <p className="text-[10px] md:text-xs font-medium text-zinc-300 uppercase tracking-wider opacity-80 mt-0.5 leading-none">
                                {song.artist}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </section>
        
        {/* Trending Section - Reduced top margin for mobile (mt-2) */}
        <section className="px-6 md:px-12 mt-2 md:mt-16">
             <h3 className="text-xl md:text-2xl font-bold tracking-tight text-white mb-6 font-syne">Trending Collections</h3>
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 auto-rows-[160px] md:auto-rows-[180px]">
                 <div className="sm:col-span-2 sm:row-span-2 relative rounded-3xl overflow-hidden group cursor-pointer border border-white/5 active:scale-[0.98] transition-transform">
                     <img src={TRENDING_PLAYLISTS[0].coverUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                     <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors p-6 md:p-8 flex flex-col justify-end">
                         <span className="text-fuchsia-400 font-bold tracking-widest text-[10px] uppercase mb-2">Top Charts</span>
                         <h4 className="text-2xl md:text-3xl font-bold text-white mb-2 font-syne">{TRENDING_PLAYLISTS[0].name}</h4>
                         <p className="text-zinc-300 line-clamp-2 text-sm md:text-base">{TRENDING_PLAYLISTS[0].description}</p>
                     </div>
                 </div>

                 {TRENDING_PLAYLISTS.slice(1).map((playlist, i) => (
                     <div key={`${playlist.id}-${i}`} className="relative rounded-3xl overflow-hidden group cursor-pointer border border-white/5 bg-zinc-900/50 active:scale-95 transition-transform">
                         <div className="absolute inset-0 flex">
                            <div className="w-1/2 h-full">
                                <img src={playlist.coverUrl} className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity" />
                            </div>
                            <div className="w-1/2 bg-gradient-to-l from-[#09090b] to-transparent"></div>
                         </div>
                         <div className="absolute inset-0 p-5 flex flex-col justify-center items-end text-right z-10">
                             <h4 className="font-bold text-lg mb-1 group-hover:text-fuchsia-400 transition-colors font-syne">{playlist.name}</h4>
                             <p className="text-xs text-zinc-500 line-clamp-2 max-w-[120px]">{playlist.description}</p>
                         </div>
                     </div>
                 ))}
             </div>
        </section>
    </div>
  );

  return (
    <div className="flex h-screen bg-[#09090b] text-white selection:bg-fuchsia-500/30 overflow-hidden font-sans">
      <Sidebar 
        currentView={currentView} 
        onViewChange={handleViewChange} 
        collapsed={isSidebarCollapsed}
        toggleCollapsed={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />
      
      <main className="flex-1 relative h-full flex flex-col overflow-hidden">
        {!isVideoMode && (
          // Changed md:left and md:hidden to lg:left and lg:hidden for Tablet Vertical support
          <header 
              className={`fixed top-0 ${isSidebarCollapsed ? 'lg:left-20' : 'lg:left-64'} left-0 right-0 pt-8 pb-3 lg:py-0 h-20 lg:h-20 px-6 md:px-12 flex items-center justify-between z-40 transition-all duration-500 ease-in-out lg:hidden ${isHeaderVisible ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0 pointer-events-none'} ${isScrolled ? 'bg-[#09090b]/90 backdrop-blur-xl border-b border-white/5 shadow-lg' : 'bg-gradient-to-b from-black/80 via-black/40 to-transparent'}`}
          >
              <div className="lg:hidden flex items-center gap-3 transition-all duration-500 absolute left-6 top-1/2 -translate-y-1/2 mt-1">
                   <div className="w-10 h-10">
                      <Logo className="w-full h-full drop-shadow-md" />
                   </div>
                   <span className="font-bold tracking-tight font-syne drop-shadow-md text-2xl">NeoStream</span>
              </div>

              {/* Updated Live button: Transparent background */}
              <div className="absolute right-6 top-1/2 -translate-y-1/2 mt-1 z-10">
                  <button className="flex items-center gap-2 text-[10px] md:text-xs font-bold uppercase tracking-widest text-zinc-400 hover:text-white transition-colors bg-transparent px-3 py-1.5 rounded-full backdrop-blur-md hover:bg-white/5 shadow-lg">
                      <span className="w-1.5 h-1.5 rounded-full bg-fuchsia-500 animate-pulse"></span>
                      Live
                  </button>
              </div>
          </header>
        )}

        <div className="flex-1 overflow-y-auto overflow-x-hidden relative scroll-smooth scrollbar-none" onScroll={handleScroll}>
            <div className="relative z-10 h-full">
                {isVideoMode && currentSong ? (
                    <VideoOverlay 
                      song={currentSong} 
                      playbackState={playbackState} 
                      isActive={isVideoMode} 
                      onClose={() => setIsVideoMode(false)}
                      onPlayRecommend={(s) => {
                          setCurrentSong(s);
                          setPlaybackState(PlaybackState.PLAYING);
                      }}
                      isPanelOpen={isVideoPanelOpen}
                      setIsPanelOpen={setIsVideoPanelOpen}
                      isSidebarCollapsed={isSidebarCollapsed}
                    />
                ) : (
                    <>
                        {currentView === ViewMode.HOME && renderHome()}
                        {currentView === ViewMode.AI_DJ && <AIDJView />}
                        {currentView === ViewMode.PROFILE && <ProfileView />}
                        {currentView === ViewMode.SEARCH && <SearchView />}
                        {currentView === ViewMode.LIBRARY && <LibraryView isSidebarCollapsed={isSidebarCollapsed} />}
                        {currentView === ViewMode.LIKED_SONGS && (
                            <LikedSongsView 
                                onPlaySong={handlePlaySong} 
                                currentSongId={currentSong?.id}
                            />
                        )}
                    </>
                )}
            </div>
        </div>
      </main>

      {!isVideoMode && <MobileNav currentView={currentView} onViewChange={handleViewChange} />}

      <PlayerBar 
        currentSong={currentSong} 
        playbackState={playbackState} 
        isVideoMode={isVideoMode}
        onTogglePlay={handleTogglePlay}
        onToggleVideo={handleToggleVideo}
        isPanelOpen={isVideoPanelOpen}
        isSidebarCollapsed={isSidebarCollapsed}
      />
    </div>
  );
}

export default App;
