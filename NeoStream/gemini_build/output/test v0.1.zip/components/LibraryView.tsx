
import React, { useState } from 'react';
import { 
    Play, PlusCircle, User, Activity, Flame, Clock, BarChart3, X, Share2, 
    TrendingUp, Zap, Sparkles, Fingerprint, Smile, Trophy, Crown, Medal, Target, Rocket, Hexagon, Hash 
} from './Icon';
import { TRENDING_PLAYLISTS, MOCK_SONGS } from '../constants';

type FilterType = 'all' | 'playlists' | 'artists' | 'albums';

interface LibraryViewProps {
    isSidebarCollapsed?: boolean;
}

const LibraryView: React.FC<LibraryViewProps> = ({ isSidebarCollapsed = false }) => {
  const [filter, setFilter] = useState<FilterType>('all');
  const [showStats, setShowStats] = useState(false);

  // --- STATS MODAL COMPONENT ---
  const StatsModal = () => (
      <div 
        className={`fixed top-0 bottom-0 right-0 z-[100] flex items-center justify-center animate-in fade-in zoom-in-95 duration-500 p-4 md:p-0 transition-all ease-in-out
        ${isSidebarCollapsed ? 'left-0 lg:left-20' : 'left-0 lg:left-72'}`} 
      >
          {/* Backdrop inside the adjusted container */}
          <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" onClick={() => setShowStats(false)}></div>
          
          <div 
            className={`w-full max-w-[1400px] h-full md:h-[95vh] bg-[#09090b] md:border border-white/10 overflow-hidden shadow-2xl flex flex-col relative md:rounded-[2rem]`}
          >
              
              {/* Modal Controls */}
              <div className="absolute top-4 right-4 md:top-6 md:right-6 z-50 flex gap-2">
                 <button className="p-3 rounded-full bg-black/40 hover:bg-white/10 border border-white/5 transition-colors group backdrop-blur-md">
                    <Share2 className="w-5 h-5 text-zinc-400 group-hover:text-white" />
                 </button>
                 <button onClick={() => setShowStats(false)} className="p-3 rounded-full bg-black/40 hover:bg-red-500/20 border border-white/5 transition-colors group backdrop-blur-md">
                      <X className="w-5 h-5 text-zinc-400 group-hover:text-red-400" />
                  </button>
              </div>

              {/* Main Layout Container */}
              <div className="w-full h-full overflow-y-auto md:overflow-hidden flex flex-col md:flex-row">
                  
                  {/* --- LEFT PANEL: THE PASSPORT --- */}
                  <div className="w-full md:w-[350px] shrink-0 bg-[#0c0c0e] border-b md:border-b-0 md:border-r border-white/5 p-6 md:p-8 pt-16 md:pt-12 flex flex-col relative min-h-[500px] md:min-h-full overflow-hidden">
                      {/* Animated Background Mesh */}
                      <div className="absolute top-[-20%] left-[-20%] w-[140%] h-[60%] bg-gradient-to-b from-indigo-600/20 via-fuchsia-600/10 to-transparent blur-[80px] opacity-60 pointer-events-none animate-pulse"></div>
                      
                      <div className="relative z-10 flex flex-col items-center text-center h-full">
                          
                          {/* Neural ID Badge */}
                          <div className="flex items-center gap-2 mb-8 bg-white/5 px-4 py-1.5 rounded-full border border-white/10 shadow-[0_0_15px_rgba(0,0,0,0.5)] backdrop-blur-md">
                               <div className="w-4 h-4 rounded bg-gradient-to-tr from-fuchsia-500 to-indigo-500 flex items-center justify-center font-bold font-syne text-white text-[8px] shadow-lg">N</div>
                               <span className="text-[10px] font-bold tracking-[0.2em] text-zinc-300 uppercase">Neural ID 2025</span>
                          </div>
                          
                          {/* Profile Image - Holographic Effect */}
                          <div className="relative w-40 h-40 mb-6 group cursor-pointer">
                              <div className="absolute inset-0 rounded-full border border-fuchsia-500/30 animate-[spin_10s_linear_infinite]"></div>
                              <div className="absolute inset-2 rounded-full border border-indigo-500/30 animate-[spin_15s_linear_infinite_reverse]"></div>
                              
                              <div className="absolute inset-0 rounded-full bg-fuchsia-500/20 blur-xl group-hover:blur-2xl transition-all duration-500 opacity-50"></div>
                              
                              <div className="relative z-10 w-full h-full rounded-full p-1 bg-gradient-to-br from-zinc-800 to-black shadow-2xl">
                                  <img src="https://i.pravatar.cc/150?img=33" className="w-full h-full rounded-full object-cover" />
                              </div>
                              
                              {/* Level Badge */}
                              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-black border border-fuchsia-500/50 text-fuchsia-400 text-[10px] font-black px-3 py-1 rounded-full shadow-lg z-20">
                                  LVL 42
                              </div>
                          </div>
                          
                          <h2 className="text-3xl md:text-4xl font-black font-syne text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-400 mb-2">Alex Cypher</h2>
                          
                          <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-8 rounded-full bg-gradient-to-r from-fuchsia-500/10 to-indigo-500/10 border border-fuchsia-500/20 text-xs font-bold uppercase tracking-widest text-white shadow-[0_0_10px_rgba(192,132,252,0.1)]">
                             <Zap className="w-3 h-3 text-yellow-400 fill-yellow-400" /> Sonic Explorer
                          </div>

                          {/* Key Stats Grid */}
                          <div className="grid grid-cols-1 gap-3 w-full mt-auto mb-4">
                              <div className="p-4 rounded-2xl bg-gradient-to-r from-white/5 to-transparent border border-white/5 flex items-center justify-between group hover:border-fuchsia-500/30 transition-colors">
                                  <div className="text-left">
                                      <span className="block text-[10px] text-zinc-500 uppercase tracking-widest mb-0.5">Top Genre</span>
                                      <span className="text-lg font-bold font-syne text-white group-hover:text-fuchsia-400 transition-colors">Synthwave</span>
                                  </div>
                                  <TrendingUp className="w-5 h-5 text-zinc-600 group-hover:text-fuchsia-500 transition-colors" />
                              </div>
                              <div className="p-4 rounded-2xl bg-gradient-to-r from-white/5 to-transparent border border-white/5 flex items-center justify-between group hover:border-indigo-500/30 transition-colors">
                                  <div className="text-left">
                                      <span className="block text-[10px] text-zinc-500 uppercase tracking-widest mb-0.5">Total Time</span>
                                      <span className="text-lg font-bold font-syne text-white group-hover:text-indigo-400 transition-colors">1,204h</span>
                                  </div>
                                  <Clock className="w-5 h-5 text-zinc-600 group-hover:text-indigo-500 transition-colors" />
                              </div>
                          </div>
                      </div>
                  </div>

                  {/* --- RIGHT PANEL: DEEP ANALYTICS --- */}
                  <div className="flex-1 p-6 md:p-10 md:overflow-y-auto scrollbar-hide bg-[#09090b] relative">
                      
                      {/* Header */}
                      <div className="flex items-center gap-3 mb-10">
                          <div className="p-2 bg-fuchsia-500/10 rounded-lg border border-fuchsia-500/20">
                             <BarChart3 className="w-6 h-6 text-fuchsia-500" />
                          </div>
                          <h3 className="text-3xl font-black font-syne tracking-tight text-white">Sonic Intelligence</h3>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-20">
                          
                          {/* 1. RARITY SCORE (Large Card) */}
                          <div className="lg:col-span-8 relative overflow-hidden rounded-3xl bg-black border border-white/10 p-8 flex flex-col md:flex-row items-center justify-between gap-8 group">
                              {/* Animated Gradients */}
                              <div className="absolute top-0 right-0 w-64 h-64 bg-fuchsia-600/20 blur-[100px] rounded-full pointer-events-none group-hover:bg-fuchsia-600/30 transition-colors duration-700"></div>
                              <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-600/20 blur-[100px] rounded-full pointer-events-none group-hover:bg-indigo-600/30 transition-colors duration-700"></div>
                              
                              <div className="relative z-10 max-w-md text-center md:text-left">
                                  <div className="flex items-center justify-center md:justify-start gap-2 mb-3">
                                     <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                                     <span className="text-xs font-bold text-amber-300 uppercase tracking-widest">Rare Status</span>
                                  </div>
                                  <h4 className="text-3xl md:text-4xl font-bold text-white mb-3 font-syne leading-tight">Your taste is exceptional.</h4>
                                  <p className="text-zinc-400 text-sm leading-relaxed">
                                      You explore the depths of sound where few others venture. Your sonic fingerprint is more unique than <span className="text-white font-bold">92%</span> of the population.
                                  </p>
                              </div>

                              <div className="relative z-10 flex items-center justify-center">
                                  <div className="relative w-40 h-40 md:w-48 md:h-48 group-hover:scale-105 transition-transform duration-500">
                                      <svg className="w-full h-full rotate-[-90deg]" viewBox="0 0 100 100">
                                          <circle cx="50" cy="50" r="45" fill="none" stroke="#18181b" strokeWidth="6" />
                                          <circle 
                                            cx="50" cy="50" r="45" 
                                            fill="none" 
                                            stroke="url(#gradient-circle)" 
                                            strokeWidth="6" 
                                            strokeDasharray="283" 
                                            strokeDashoffset="22" 
                                            strokeLinecap="round"
                                            className="drop-shadow-[0_0_15px_rgba(192,132,252,0.6)] animate-[dash_1.5s_ease-out_forwards]"
                                          />
                                          <defs>
                                            <linearGradient id="gradient-circle" x1="0%" y1="0%" x2="100%" y2="0%">
                                              <stop offset="0%" stopColor="#c084fc" />
                                              <stop offset="100%" stopColor="#f59e0b" />
                                            </linearGradient>
                                          </defs>
                                      </svg>
                                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                                          <span className="text-5xl md:text-6xl font-black font-syne text-white drop-shadow-lg">92</span>
                                          <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Percentile</span>
                                      </div>
                                  </div>
                              </div>
                          </div>

                          {/* 2. AUDIO AURA (REDESIGNED AS UNIQUE NFT ARTIFACT) */}
                          <div className="lg:col-span-4 bg-[#08080a] border border-white/10 rounded-3xl p-1 relative overflow-hidden flex flex-col group hover:border-fuchsia-500/30 transition-all">
                              {/* Scanner Line Effect */}
                              <div className="absolute top-0 left-0 right-0 h-1 bg-fuchsia-500/50 shadow-[0_0_20px_#d946ef] z-30 animate-[scan_4s_linear_infinite] opacity-20 pointer-events-none"></div>
                              
                              <div className="bg-[#0c0c0e] w-full h-full rounded-[1.3rem] p-6 flex flex-col items-center relative overflow-hidden">
                                    {/* Header */}
                                    <div className="w-full flex justify-between items-center mb-6 z-20">
                                        <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest text-zinc-500">
                                            <Hexagon className="w-3 h-3 text-fuchsia-500" /> Neural Artifact
                                        </div>
                                        <div className="px-2 py-0.5 rounded border border-amber-500/20 bg-amber-500/10 text-[8px] font-bold text-amber-400 tracking-widest uppercase">
                                            Legendary
                                        </div>
                                    </div>

                                    {/* Generative Visual Core */}
                                    <div className="relative w-48 h-48 mb-6 z-10 flex items-center justify-center">
                                        {/* Outer Ring */}
                                        <div className="absolute inset-0 rounded-full border border-dashed border-white/10 animate-[spin_20s_linear_infinite]"></div>
                                        {/* Middle Glitch Ring */}
                                        <div className="absolute inset-4 rounded-full border-2 border-fuchsia-500/20 border-t-fuchsia-500 border-l-transparent animate-[spin_5s_linear_infinite_reverse]"></div>
                                        {/* Core Gradient Orb */}
                                        <div className="absolute inset-8 rounded-full bg-gradient-to-tr from-fuchsia-600 via-indigo-600 to-cyan-500 blur-md opacity-80 animate-pulse"></div>
                                        {/* Geometric Overlay */}
                                        <div className="absolute inset-10 border border-white/30 rotate-45 backdrop-blur-[1px]"></div>
                                        <div className="absolute inset-12 border border-white/20 rotate-12 backdrop-blur-[1px]"></div>
                                        
                                        {/* Central Identifier */}
                                        <div className="absolute inset-0 flex items-center justify-center">
                                            <span className="font-mono text-[10px] text-white mix-blend-overlay tracking-widest opacity-80">8X-29</span>
                                        </div>
                                    </div>

                                    {/* Footer Info */}
                                    <div className="w-full mt-auto z-20">
                                        <div className="flex justify-between items-end mb-2">
                                            <h4 className="text-white font-syne text-xl font-bold leading-none">Neon<br/>Genesis</h4>
                                            <span className="text-[10px] font-mono text-zinc-500">#8291</span>
                                        </div>
                                        <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden">
                                            <div className="h-full w-[85%] bg-gradient-to-r from-fuchsia-500 to-cyan-500"></div>
                                        </div>
                                        <div className="flex justify-between mt-1.5 text-[9px] text-zinc-500 font-mono">
                                            <span>MINTED 2025</span>
                                            <span className="flex items-center gap-1"><Hash className="w-2 h-2" /> VERIFIED</span>
                                        </div>
                                    </div>

                                    {/* Ambient Glow Background */}
                                    <div className="absolute inset-0 bg-gradient-to-b from-fuchsia-900/10 to-transparent pointer-events-none"></div>
                              </div>
                          </div>

                          {/* 3. CURRENT OBSESSION */}
                          <div className="lg:col-span-6 bg-white/[0.02] border border-white/5 p-6 rounded-3xl hover:bg-white/[0.04] transition-colors group">
                              <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                                  <Flame className="w-4 h-4 text-orange-500 fill-orange-500/20" /> Current Obsession
                              </h4>
                              <div className="flex items-center gap-5">
                                  <div className="relative group/cover shrink-0">
                                      <img src={MOCK_SONGS[0].coverUrl} className="w-24 h-24 rounded-2xl object-cover shadow-2xl border border-white/5 group-hover:rotate-2 transition-transform duration-300" />
                                      <div className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-lg border border-red-400 animate-bounce">
                                          HOT
                                      </div>
                                  </div>
                                  <div className="flex-1 min-w-0">
                                      <div className="font-bold text-2xl text-white font-syne mb-1 truncate">{MOCK_SONGS[0].title}</div>
                                      <div className="text-zinc-400 text-sm mb-3 truncate">{MOCK_SONGS[0].artist}</div>
                                      
                                      <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                                          <div className="bg-gradient-to-r from-orange-500 to-red-500 h-full w-[85%] rounded-full shadow-[0_0_10px_#f97316]"></div>
                                      </div>
                                      <div className="flex justify-between mt-1">
                                          <span className="text-[10px] text-zinc-500 font-bold uppercase">Repeat Index</span>
                                          <span className="text-[10px] text-orange-400 font-bold">High</span>
                                      </div>
                                  </div>
                              </div>
                          </div>

                           {/* 4. CHRONOTYPE & METRICS */}
                           <div className="lg:col-span-6 grid grid-cols-2 gap-4">
                               {/* Chronotype Bubble */}
                               <div className="bg-gradient-to-br from-blue-900/10 to-transparent border border-white/5 p-6 rounded-3xl flex flex-col relative overflow-hidden group hover:border-blue-500/30 transition-all">
                                   <div className="absolute top-0 right-0 w-20 h-20 bg-blue-500/10 blur-xl rounded-full -mr-10 -mt-10"></div>
                                   <div className="flex items-center gap-2 mb-4">
                                       <div className="p-1.5 bg-blue-500/20 rounded-lg text-blue-300">
                                           <Clock className="w-4 h-4" />
                                       </div>
                                       <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">Chronotype</span>
                                   </div>
                                   <div className="mt-auto">
                                       <div className="flex items-baseline gap-1">
                                           <span className="text-4xl font-black text-white font-syne tracking-tight">02:00</span>
                                           <span className="text-sm font-bold text-zinc-500 font-syne">AM</span>
                                       </div>
                                       <div className="h-1 w-full bg-blue-900/30 rounded-full mt-3 overflow-hidden">
                                           <div className="h-full bg-blue-500 w-[70%] rounded-full"></div>
                                       </div>
                                       <p className="text-[10px] text-zinc-400 mt-2 font-medium">Peak activity window</p>
                                   </div>
                               </div>
                               
                               {/* Mood Bubble */}
                               <div className="bg-gradient-to-br from-pink-900/10 to-transparent border border-white/5 p-6 rounded-3xl flex flex-col relative overflow-hidden group hover:border-pink-500/30 transition-all">
                                   <div className="absolute top-0 right-0 w-20 h-20 bg-pink-500/10 blur-xl rounded-full -mr-10 -mt-10"></div>
                                   <div className="flex items-center gap-2 mb-4">
                                       <div className="p-1.5 bg-pink-500/20 rounded-lg text-pink-300">
                                           <Smile className="w-4 h-4" />
                                       </div>
                                       <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">Dominant Mood</span>
                                   </div>
                                   <div className="mt-auto">
                                       <div className="text-2xl font-black text-white font-syne leading-none mb-1">Bass Face</div>
                                       <div className="flex items-center gap-1 mt-3">
                                            {[1,2,3,4,5].map(i => (
                                                <div key={i} className={`h-1.5 flex-1 rounded-full ${i <= 4 ? 'bg-pink-500' : 'bg-pink-900/30'}`}></div>
                                            ))}
                                       </div>
                                       <p className="text-[10px] text-zinc-400 mt-2 font-medium">Intensity: 8.5/10</p>
                                   </div>
                               </div>
                           </div>

                           {/* 5. ACHIEVEMENTS - CLEANER & BIGGER */}
                           <div className="col-span-full bg-[#0c0c0e] border border-white/5 p-8 rounded-3xl relative overflow-hidden">
                                
                                <div className="flex items-end justify-between mb-8 relative z-10">
                                    <div className="flex items-center gap-4">
                                        <h4 className="text-3xl font-black text-white font-syne tracking-tight">
                                           Recent Achievements
                                        </h4>
                                        {/* Subtle badge integrated with background */}
                                        <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-full border border-white/5 text-[10px] font-bold text-zinc-400">
                                            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                                            5 / 24 Unlocked
                                        </div>
                                    </div>
                                    
                                    <button className="text-xs font-bold text-zinc-500 hover:text-white transition-colors">View All</button>
                                </div>
                                
                                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-4 relative z-10">
                                    {[
                                        { icon: Crown, label: "Trendsetter", desc: "Top 1% Listener", color: "text-yellow-200", bg: "from-yellow-500/10 to-transparent", ring: "ring-yellow-500/20" },
                                        { icon: Target, label: "Obsessed", desc: "50 Repeats", color: "text-emerald-200", bg: "from-emerald-500/10 to-transparent", ring: "ring-emerald-500/20" },
                                        { icon: Rocket, label: "Early Bird", desc: "Pre-release", color: "text-blue-200", bg: "from-blue-500/10 to-transparent", ring: "ring-blue-500/20" },
                                        { icon: Zap, label: "Power User", desc: "4h Session", color: "text-fuchsia-200", bg: "from-fuchsia-500/10 to-transparent", ring: "ring-fuchsia-500/20" },
                                        { icon: Medal, label: "Loyalist", desc: "3 Year Sub", color: "text-orange-200", bg: "from-orange-500/10 to-transparent", ring: "ring-orange-500/20" },
                                    ].map((badge, i) => (
                                        <div key={i} className={`flex flex-col items-center text-center p-4 rounded-2xl bg-gradient-to-b ${badge.bg} border border-white/5 hover:border-white/10 transition-all cursor-pointer group hover:-translate-y-1 relative overflow-hidden`}>
                                            <div className={`w-12 h-12 rounded-full flex items-center justify-center bg-white/5 ring-1 ${badge.ring} shadow-[0_0_15px_rgba(0,0,0,0.2)] mb-3 group-hover:scale-110 transition-transform`}>
                                                <badge.icon className={`w-5 h-5 ${badge.color}`} />
                                            </div>
                                            <span className="text-sm font-bold text-white mb-0.5 font-syne">{badge.label}</span>
                                            <span className="text--[10px] text-zinc-500 font-medium">{badge.desc}</span>
                                        </div>
                                    ))}
                                </div>
                           </div>

                          {/* 6. WEEKLY RHYTHM CHART - BLENDED BACKGROUND (NO BARS ABOVE) */}
                           <div className="col-span-full bg-white/[0.02] border border-white/5 p-8 rounded-3xl">
                               <div className="flex justify-between items-center mb-8">
                                   <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                                      <Activity className="w-4 h-4 text-teal-400" /> Weekly Rhythm
                                  </h4>
                                  <div className="flex items-center gap-2">
                                      <span className="w-2 h-2 rounded-full bg-teal-500"></span>
                                      <span className="text-[10px] text-zinc-400 uppercase tracking-wider">Avg. 4.2h</span>
                                  </div>
                               </div>
                               
                              <div className="relative h-40 w-full px-2">
                                  {/* Background Grid Lines (Subtle) */}
                                  <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-30">
                                      <div className="w-full h-px bg-white/5 border-t border-dashed border-white/10"></div>
                                      <div className="w-full h-px bg-white/5 border-t border-dashed border-white/10"></div>
                                      <div className="w-full h-px bg-white/5 border-t border-dashed border-white/10"></div>
                                      <div className="w-full h-px bg-transparent"></div>
                                  </div>

                                  <div className="flex items-end justify-between h-full gap-4 relative z-10">
                                      {[40, 65, 30, 80, 50, 90, 45].map((h, i) => (
                                          <div key={i} className="flex-1 flex flex-col justify-end gap-3 group h-full relative cursor-pointer">
                                              {/* Tooltip on Hover */}
                                              <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-white text-black text-[10px] font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-20 pointer-events-none transform translate-y-2 group-hover:translate-y-0">
                                                  {Math.floor(h / 10)}h 30m
                                              </div>
                                              
                                              {/* Blended Bar / Candle */}
                                              <div className="w-full h-full flex items-end justify-center">
                                                  <div 
                                                    className="w-full bg-gradient-to-t from-teal-500/80 via-teal-500/20 to-transparent rounded-t-sm transition-all duration-500 group-hover:from-teal-400 group-hover:via-teal-400/30" 
                                                    style={{ height: `${h}%` }}
                                                  ></div>
                                              </div>
                                              <span className="text-[10px] text-center text-zinc-600 font-bold uppercase group-hover:text-white transition-colors">{['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][i]}</span>
                                          </div>
                                      ))}
                                  </div>
                              </div>
                           </div>

                      </div>
                  </div>
              </div>
          </div>
      </div>
  );

  return (
    // Increased pt-40 and pb-64 for clearance
    <div className="h-full flex flex-col animate-in fade-in duration-700 pb-64 relative pt-40 px-6 md:px-12">
        {/* Header - Responsive with Flex Wrap */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
            <div className="flex-1 min-w-0">
                <h1 className="text-4xl md:text-6xl font-black font-syne text-white mb-2 tracking-tight">Library</h1>
                <p className="text-zinc-400 text-sm md:text-base">Your collection of {MOCK_SONGS.length + 12} items.</p>
            </div>
            
            <div className="flex flex-wrap items-center gap-3">
                 <button 
                    onClick={() => setShowStats(true)}
                    className="group relative px-6 py-3 rounded-full bg-white text-black font-bold text-sm shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:shadow-[0_0_30px_rgba(192,132,252,0.4)] transition-all flex items-center gap-2 hover:scale-105 active:scale-95 whitespace-nowrap overflow-hidden"
                 >
                    <div className="absolute inset-0 bg-gradient-to-r from-fuchsia-500 to-indigo-500 opacity-0 group-hover:opacity-10 transition-opacity"></div>
                    <BarChart3 className="w-4 h-4 text-fuchsia-600" /> 
                    <span className="relative z-10">View Neural Recap</span>
                 </button>
                 <button className="p-3 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 transition-colors">
                    <PlusCircle className="w-5 h-5 text-white" />
                 </button>
            </div>
        </div>

        {/* Filters - Improved visibility and positioning */}
        <div className="sticky top-20 z-20 bg-[#09090b]/80 backdrop-blur-xl py-4 -mx-6 px-6 md:-mx-12 md:px-12 border-b border-white/5 mb-6">
            <div className="flex gap-2 overflow-x-auto scrollbar-hide">
                {(['all', 'playlists', 'artists', 'albums'] as FilterType[]).map((f) => (
                    <button
                        key={f}
                        onClick={() => setFilter(f)}
                        className={`px-6 py-2 rounded-full text-sm font-bold uppercase tracking-wider border transition-all whitespace-nowrap
                        ${filter === f 
                            ? 'bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.3)]' 
                            : 'bg-white/5 text-zinc-300 border-white/10 hover:border-white/30 hover:bg-white/10 hover:text-white'}`}
                    >
                        {f}
                    </button>
                ))}
            </div>
        </div>

        {/* Grid Content */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {/* New Playlist Card - Glassmorphism */}
            <div className="aspect-square rounded-2xl border border-white/10 bg-white/[0.02] hover:bg-white/[0.05] hover:border-fuchsia-500/30 transition-all cursor-pointer flex flex-col items-center justify-center group relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-fuchsia-500/5 to-indigo-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:bg-white/10 transition-all relative z-10 border border-white/5">
                    <PlusCircle className="w-8 h-8 text-zinc-400 group-hover:text-white transition-colors" />
                </div>
                <span className="font-bold text-zinc-400 group-hover:text-white transition-colors text-sm relative z-10 font-syne">Create Playlist</span>
            </div>

            {/* Mock Data Rendering */}
            {TRENDING_PLAYLISTS.map((playlist) => (
                 <div key={playlist.id} className="group cursor-pointer">
                    <div className="aspect-square rounded-2xl overflow-hidden mb-3 relative border border-white/5 shadow-lg">
                        <img src={playlist.coverUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                            <Play className="w-12 h-12 fill-white text-white drop-shadow-xl hover:scale-110 transition-transform" />
                        </div>
                    </div>
                    <h4 className="font-bold text-white truncate font-syne text-lg group-hover:text-fuchsia-400 transition-colors">{playlist.name}</h4>
                    <p className="text-xs text-zinc-500 uppercase tracking-wider">Playlist • {playlist.songs.length} Tracks</p>
                 </div>
            ))}
            
            {MOCK_SONGS.map((song) => (
                 <div key={`lib-${song.id}`} className="group cursor-pointer">
                    <div className="aspect-square rounded-2xl overflow-hidden mb-3 relative border border-white/5 shadow-lg">
                        <img src={song.coverUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale-[30%] group-hover:grayscale-0" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                            <Play className="w-12 h-12 fill-white text-white drop-shadow-xl hover:scale-110 transition-transform" />
                        </div>
                    </div>
                    <h4 className="font-bold text-white truncate font-syne text-lg group-hover:text-fuchsia-400 transition-colors">{song.title}</h4>
                    <p className="text-xs text-zinc-500 uppercase tracking-wider">Song • {song.artist}</p>
                 </div>
            ))}
             {/* Duplicate to demonstrate scrolling/padding */}
             {MOCK_SONGS.map((song) => (
                 <div key={`lib-dup-${song.id}`} className="group cursor-pointer">
                    <div className="aspect-square rounded-2xl overflow-hidden mb-3 relative border border-white/5 shadow-lg">
                        <img src={song.coverUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale-[30%] group-hover:grayscale-0" />
                         <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
                            <Play className="w-12 h-12 fill-white text-white drop-shadow-xl hover:scale-110 transition-transform" />
                        </div>
                    </div>
                    <h4 className="font-bold text-white truncate font-syne text-lg group-hover:text-fuchsia-400 transition-colors">{song.title}</h4>
                    <p className="text-xs text-zinc-500 uppercase tracking-wider">Song • {song.artist}</p>
                 </div>
            ))}
        </div>

        {showStats && <StatsModal />}
    </div>
  );
};

export default LibraryView;
