
import React, { useState } from 'react';
import { Compass, Search, Play } from './Icon';

const EXPLORE_CARDS = [
  // 0: Vibe (Large Left)
  { id: '1', title: 'Late Night Drive', type: 'VIBE', span: 'col-span-2 row-span-1 md:row-span-2', img: 'https://images.unsplash.com/photo-1493225255756-d9584f8606e9?auto=format&fit=crop&q=80&w=800', color: 'from-purple-900 to-indigo-900' },
  // 1 & 2: Accordion Pair (Genre & Trending)
  { id: '2', title: 'Pop', type: 'GENRE', span: 'col-span-1 row-span-1', img: 'https://images.unsplash.com/photo-1514525253440-b39345208668?auto=format&fit=crop&q=80&w=400', color: 'from-pink-500 to-rose-500' },
  { id: '3', title: 'New Releases', type: 'TRENDING', span: 'col-span-1 row-span-1', img: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=400', color: 'from-emerald-500 to-teal-900' },
  // 3+: Rest of the grid
  { id: '4', title: 'Workout', type: 'ACTIVITY', span: 'col-span-1 row-span-2', img: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=400', color: 'from-orange-600 to-red-900' },
  { id: '5', title: 'Focus Flow', type: 'VIBE', span: 'col-span-2 row-span-1', img: 'https://images.unsplash.com/photo-1516280440614-6697288d5d38?auto=format&fit=crop&q=80&w=800', color: 'from-blue-600 to-cyan-900' },
  { id: '6', title: 'Hip-Hop', type: 'GENRE', span: 'col-span-1 row-span-1', img: 'https://images.unsplash.com/photo-1605722243979-fe0be8190c09?auto=format&fit=crop&q=80&w=400', color: 'from-yellow-600 to-orange-800' },
  { id: '7', title: 'Indie', type: 'GENRE', span: 'col-span-1 row-span-1', img: 'https://images.unsplash.com/photo-1524368535928-5b5e00ddc76b?auto=format&fit=crop&q=80&w=400', color: 'from-lime-600 to-green-800' },
];

const SearchView = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  // Courbe de bézier pour une transition très fluide (ease-out smooth)
  const smoothTransition = "transition-all duration-700 ease-[cubic-bezier(0.25,1,0.5,1)]";

  // Helper to render a card
  const renderCard = (card: any, isAccordion = false) => {
    // Determine font size based on card type and span
    // Smaller font for single column cards to prevent cutoff
    const isLarge = card.span.includes('col-span-2') || isAccordion;
    const titleSize = isLarge 
        ? 'text-3xl sm:text-4xl md:text-5xl lg:text-6xl' 
        : 'text-2xl md:text-4xl';

    return (
      <div 
        key={card.id} 
        className={`relative overflow-hidden cursor-pointer group border border-white/5 hover:border-fuchsia-500/40 transition-all duration-500
        ${isAccordion ? 'w-full h-full' : card.span}
        rounded-[1.5rem] md:rounded-[2.5rem]`}
     >
         <img src={card.img} alt={card.title} className="absolute inset-0 w-full h-full object-cover object-center transition-transform duration-1000 group-hover:scale-110 group-hover:rotate-1" />
         {/* Removed mix-blend-multiply and reduced opacity for better image visibility */}
         <div className={`absolute inset-0 bg-gradient-to-br ${card.color} opacity-40 transition-opacity group-hover:opacity-30`} />
         <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
         
         {/* Padding adjusted to ensure text clears rounded corners */}
         <div className="absolute inset-0 p-5 md:p-8 flex flex-col justify-between">
             <span className="self-start px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md text-[8px] md:text-[10px] font-black tracking-[0.2em] uppercase border border-white/10 text-white shadow-lg">
                {card.type}
             </span>
             
             <div className="flex justify-between items-end gap-2 translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                 {/* Titles with word break and tightening */}
                 <h3 className={`font-black font-syne text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)] leading-[0.9] break-words ${titleSize}`}>
                    {card.title}
                 </h3>
                 
                 {/* Reverted to clean, minimal Play button - removed Neo imprint */}
                 <div className="w-10 h-10 md:w-14 md:h-14 rounded-full bg-white text-black flex items-center justify-center opacity-0 scale-50 group-hover:opacity-100 group-hover:scale-100 transition-all duration-300 shadow-xl shrink-0">
                     <Play className="w-4 h-4 md:w-6 md:h-6 fill-current ml-0.5" />
                 </div>
             </div>
         </div>
     </div>
    );
  };

  return (
    <div className="px-4 md:p-12 pb-32 landscape:pb-8 animate-in fade-in duration-500 relative flex flex-col justify-start min-h-[calc(100vh-140px)] pt-20 landscape:pt-10 md:pt-20">
      
      {/* Search Header Container */}
      <div className="flex flex-col w-full items-center relative z-20 mb-12 landscape:mb-8 md:mb-32">
          
          {/* Title - MASSIVELY SCALED UP FOR DESKTOP */}
          <div className={`w-full flex flex-col items-center overflow-hidden ${smoothTransition} ${isFocused || searchTerm ? 'max-h-0 opacity-0 mb-0 scale-95' : 'max-h-[800px] opacity-100 scale-100 mb-[-1rem] landscape:mb-[-1.5rem] md:mb-[-5rem]'}`}>
              <h1 className="text-4xl landscape:text-5xl landscape:mt-10 sm:text-5xl md:text-[9rem] lg:text-[12rem] font-black font-syne tracking-tighter text-center drop-shadow-[0_0_40px_rgba(168,85,247,0.2)] leading-[0.9] md:leading-[0.8] bg-clip-text text-transparent bg-gradient-to-br from-white via-white to-white/30 relative z-10 pb-4 landscape:pb-2">
                 <span className="whitespace-nowrap">What are you</span><br />
                 <span className="opacity-40 select-none whitespace-nowrap">looking for?</span>
              </h1>
          </div>

          {/* Search Bar - SCALED UP FOR DESKTOP */}
          <div className={`relative w-full max-w-xl md:max-w-6xl group z-30 ${smoothTransition} ${isFocused || searchTerm ? 'mt-0 mb-8' : 'mt-2 landscape:mt-1 md:mt-24 mb-6 landscape:mb-3'}`}>
             <div className="absolute inset-0 bg-gradient-to-r from-fuchsia-600/20 via-indigo-600/20 to-blue-600/20 rounded-full blur-[80px] opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity duration-300"></div>
             
             <div 
                className="relative text-white flex items-center p-2 md:p-6 transition-all duration-300 h-16 landscape:h-14 md:h-32 backdrop-blur-xl md:backdrop-blur-3xl rounded-[2rem] md:rounded-[3rem]"
                style={{
                  background: 'radial-gradient(closest-side, rgba(20, 20, 23, 1) 0%, rgba(20, 20, 23, 0.8) 40%, rgba(20, 20, 23, 0) 100%)',
                  boxShadow: 'none'
                }}
             >
                 <div className="pl-4 md:pl-10 pr-4">
                    <Search className={`w-6 h-6 landscape:w-5 landscape:h-5 md:w-12 md:h-12 transition-all duration-500 ${isFocused ? 'text-fuchsia-400 rotate-12 scale-110' : 'text-zinc-500'}`} />
                 </div>
                 {/* Corrected Text Size for Input: Reduced from text-5xl to text-3xl to fit input better, added leading-normal */}
                 <input 
                    type="text" 
                    placeholder="Search for tracks, artists..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onFocus={() => setIsFocused(true)}
                    onBlur={() => !searchTerm && setIsFocused(false)}
                    className="flex-1 bg-transparent border-none text-xl landscape:text-lg md:text-3xl px-2 md:px-6 text-white placeholder-zinc-600 focus:outline-none font-syne font-black min-w-0 h-full tracking-tight pr-8 relative z-10 leading-normal"
                 />
             </div>
          </div>

          {/* Hashtags - SCALED UP FOR DESKTOP */}
          <div className={`w-full overflow-hidden ${smoothTransition} ${isFocused || searchTerm ? 'max-h-0 opacity-0 mb-0' : 'max-h-[160px] opacity-100 mb-2 landscape:mb-1'}`}>
              <div className="flex flex-nowrap md:flex-wrap justify-start md:justify-center gap-2 md:gap-4 overflow-x-auto md:overflow-visible pb-6 md:pb-0 scrollbar-hide -mx-4 px-4 mask-image-gradient-r">
                  {['#Cyberpunk', '#LoFi', '#Synthwave', '#Podcast', '#LiveEvents', '#SpatialAudio', '#Charts', '#NewArtists'].map(tag => (
                      <button key={tag} className="px-5 py-2.5 md:px-8 md:py-4 landscape:py-1.5 landscape:px-3 rounded-full bg-white/5 hover:bg-white/10 text-[10px] md:text-sm font-bold text-zinc-600 hover:text-zinc-300 transition-all uppercase tracking-widest whitespace-nowrap active:scale-95 border border-transparent hover:border-white/10">
                          {tag}
                      </button>
                  ))}
              </div>
          </div>

      </div>

      {/* 
        GRID LAYOUT - Tightened Gap and Radius to fix border bugs
        REMOVED EXPLORE HEADER
      */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 auto-rows-[160px] md:auto-rows-[320px]">
         
         {/* 1. Large Vibe Card */}
         {renderCard(EXPLORE_CARDS[0])}

         {/* 2. Accordion Container (Pop & New Releases) */}
         <div className="col-span-2 row-span-1 flex gap-4 h-full">
            <div className="flex-1 hover:flex-[4] transition-all duration-700 ease-[cubic-bezier(0.25,1,0.5,1)] min-w-0">
                {renderCard(EXPLORE_CARDS[1], true)}
            </div>
            <div className="flex-1 hover:flex-[4] transition-all duration-700 ease-[cubic-bezier(0.25,1,0.5,1)] min-w-0">
                {renderCard(EXPLORE_CARDS[2], true)}
            </div>
         </div>

         {/* 3. Remaining Cards */}
         {EXPLORE_CARDS.slice(3).map((card) => renderCard(card))}
      </div>
    </div>
  );
};

export default SearchView;
