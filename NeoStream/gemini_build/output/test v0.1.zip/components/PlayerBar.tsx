
import React, { useState, useEffect } from 'react';
import { 
  Play, Pause, SkipBack, SkipForward, Volume2, 
  Repeat, Shuffle, Heart, Video, MonitorPlay, PlusCircle, CheckCircle2,
  ListPlus, ListMusic
} from './Icon';
import { Song, PlaybackState } from '../types';

interface PlayerBarProps {
  currentSong: Song | null;
  playbackState: PlaybackState;
  isVideoMode: boolean;
  onTogglePlay: () => void;
  onToggleVideo: () => void;
  isPanelOpen?: boolean; // Optional prop
  isSidebarCollapsed?: boolean;
}

const PlayerBar: React.FC<PlayerBarProps> = ({ 
  currentSong, 
  playbackState, 
  isVideoMode, 
  onTogglePlay, 
  onToggleVideo,
  isPanelOpen = false,
  isSidebarCollapsed = false
}) => {
  const [volume, setVolume] = useState(75);
  const [progress, setProgress] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [isAdded, setIsAdded] = useState(false);

  // Simulation of progress
  useEffect(() => {
    let interval: any;
    if (playbackState === PlaybackState.PLAYING) {
      interval = setInterval(() => {
        setProgress(p => (p >= 100 ? 0 : p + 0.5));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [playbackState]);

  if (!currentSong) return null;

  return (
    <>
      {/* 
        ==========================
        MOBILE PLAYER LAYOUT - COMPACT RESTORED
        ==========================
      */}
      <div className={`lg:hidden fixed z-[120] transition-all duration-500 ease-out ${isVideoMode ? 'inset-0 bg-black pointer-events-none' : 'bottom-[64px] landscape:bottom-[48px] left-0 right-0'}`}>
        {!isVideoMode && (
            <div className="bg-[#09090b]/95 backdrop-blur-xl border-t border-white/5 h-[64px] landscape:h-[56px] flex items-center pr-4 pl-3 shadow-[0_-4px_20px_rgba(0,0,0,0.4)] relative pointer-events-auto">
                {/* Slim Progress Bar at Top */}
                <div className="absolute top-0 left-0 right-0 h-[2px] bg-white/5 pointer-events-none">
                    <div 
                        className="h-full bg-gradient-to-r from-fuchsia-500 to-indigo-500" 
                        style={{ width: `${progress}%` }} 
                    />
                </div>

                <div className="flex-1 flex items-center justify-between gap-3">
                     <div className="flex items-center gap-3 overflow-hidden flex-1 p-1 active:opacity-70 transition-opacity" onClick={onToggleVideo}>
                        <div className="w-10 h-10 rounded-md bg-zinc-800 overflow-hidden shrink-0 relative shadow-lg">
                            <img src={currentSong.coverUrl} className="w-full h-full object-cover opacity-90" alt="cover" />
                        </div>
                        <div className="flex flex-col overflow-hidden min-w-0 justify-center">
                            <span className="font-bold text-sm text-white truncate font-syne leading-tight">{currentSong.title}</span>
                            <span className="text-xs text-zinc-400 truncate">{currentSong.artist}</span>
                        </div>
                     </div>

                     <div className="flex items-center gap-1">
                        <button 
                            onClick={(e) => { e.stopPropagation(); setIsAdded(!isAdded); }}
                            className={`p-2 transition-colors active:scale-90 ${isAdded ? 'text-emerald-400' : 'text-zinc-400 hover:text-white'}`}
                        >
                            {isAdded ? <CheckCircle2 className="w-6 h-6" /> : <PlusCircle className="w-6 h-6" />}
                        </button>
                        <button 
                            onClick={(e) => { e.stopPropagation(); setIsLiked(!isLiked); }}
                            className={`p-2 transition-colors active:scale-90 ${isLiked ? 'text-fuchsia-500' : 'text-zinc-400 hover:text-white'}`}
                        >
                            <Heart className={`w-6 h-6 ${isLiked ? 'fill-current' : ''}`} />
                        </button>
                        <button 
                            onClick={(e) => { e.stopPropagation(); onTogglePlay(); }}
                            className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center shadow-lg active:scale-95 transition-transform ml-1"
                        >
                            {playbackState === PlaybackState.PLAYING ? (
                                <Pause className="w-5 h-5 fill-current" />
                            ) : (
                                <Play className="w-5 h-5 fill-current ml-0.5" />
                            )}
                        </button>
                     </div>
                </div>
            </div>
        )}
      </div>

      {/* 
        ==========================
        DESKTOP PLAYER LAYOUT - RESTORED HEIGHT, KEPT LARGE ICONS
        ==========================
      */}
      <div 
        className={`hidden lg:flex fixed z-[120] items-center pointer-events-none
        transition-[padding,bottom] duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]
        bottom-6 left-1/2 -translate-x-1/2 w-[98%] max-w-[1600px]`}
      >
        <div 
          className={`relative rounded-[2.5rem] shadow-[0_20px_50px_-10px_rgba(0,0,0,0.8)] flex items-center justify-between px-8 overflow-visible group transition-all duration-700 pointer-events-auto
          h-[88px] border border-white/10 w-full
          ${isVideoMode 
             ? 'bg-black/40 backdrop-blur-xl hover:bg-black/60' 
             : 'bg-[#0e0e10]/95 backdrop-blur-2xl'
          }`}
        >
          {/* Ambient Glow */}
          <div className={`absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-transparent to-fuchsia-500/5 pointer-events-none transition-opacity rounded-[2.5rem] overflow-hidden ${isVideoMode ? 'opacity-20' : 'opacity-100'}`} />

          {/* Left: Compact Art & Info */}
          <div className="flex items-center gap-4 w-[30%] relative z-10">
            <div className="relative group/art shrink-0">
               {/* Restored to slightly smaller container but large enough for visibility */}
               <div className={`rounded-xl overflow-hidden shadow-2xl relative z-10 border border-white/5 bg-zinc-800 transition-all w-16 h-16`}>
                  <img src={currentSong.coverUrl} className="w-full h-full object-cover" alt="cover" />
               </div>
            </div>

            <div className="flex flex-col justify-center min-w-0 gap-0.5">
              <h4 className="font-bold text-lg text-white leading-tight font-syne truncate hover:text-fuchsia-300 transition-colors cursor-pointer shadow-black drop-shadow-md">
                {currentSong.title}
              </h4>
              <span className="text-sm font-medium text-zinc-400 truncate hover:text-zinc-300 transition-colors cursor-pointer drop-shadow-md">
                {currentSong.artist}
              </span>
            </div>
            
             <div className="flex items-center gap-1 ml-2">
                  <button 
                      onClick={() => setIsLiked(!isLiked)} 
                      className={`p-2 rounded-full transition-colors ${isLiked ? 'text-fuchsia-400' : 'text-zinc-400 hover:text-white'}`}
                  >
                      <Heart className={`w-6 h-6 ${isLiked ? 'fill-current' : ''}`} />
                  </button>
                  
                  <button 
                      onClick={() => setIsAdded(!isAdded)}
                      className={`p-2 rounded-full transition-colors ${isAdded ? 'text-emerald-400' : 'text-zinc-400 hover:text-white'}`}
                  >
                      {isAdded ? <CheckCircle2 className="w-6 h-6" /> : <ListPlus className="w-6 h-6" />}
                  </button>
              </div>
          </div>

          {/* Center: Clean Controls & Progress */}
          <div className="flex flex-col items-center justify-center w-[40%] gap-1 relative z-10">
            <div className="flex items-center gap-6">
              <button className="text-zinc-400 hover:text-white transition-colors hover:scale-110 drop-shadow-md p-2">
                <Shuffle className="w-6 h-6" />
              </button>
              
              <button className="text-zinc-200 hover:text-white transition-colors hover:scale-110 active:scale-95 drop-shadow-md p-1">
                <SkipBack className="w-8 h-8 fill-current" />
              </button>
              
              {/* Play Button - Large but fitted */}
              <button 
                onClick={onTogglePlay}
                className={`w-14 h-14 rounded-full bg-white text-black flex items-center justify-center shadow-xl hover:scale-105 hover:bg-zinc-200 active:scale-95 transition-all border-none`}
              >
                 {playbackState === PlaybackState.PLAYING ? (
                    <Pause className="w-7 h-7 fill-current" />
                  ) : (
                    <Play className="w-7 h-7 fill-current ml-1" />
                  )}
              </button>

              <button className="text-zinc-200 hover:text-white transition-colors hover:scale-110 active:scale-95 drop-shadow-md p-1">
                <SkipForward className="w-8 h-8 fill-current" />
              </button>
              
              <button className="text-zinc-400 hover:text-white transition-colors hover:scale-110 drop-shadow-md p-2">
                <Repeat className="w-6 h-6" />
              </button>
            </div>

            {/* Progress Bar - Tucked close */}
            <div className="w-full flex items-center gap-3 text-[10px] font-bold text-zinc-500 font-mono drop-shadow-md mt-1 max-w-md">
                <span className="w-8 text-right">1:12</span>
                <div className="relative h-1 flex-1 bg-white/10 rounded-full group/progress cursor-pointer overflow-hidden">
                    <div 
                        className="absolute top-0 left-0 h-full bg-white rounded-full" 
                        style={{ width: `${progress}%` }}
                    />
                    <div className="absolute top-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full shadow-md opacity-0 group-hover/progress:opacity-100 transition-opacity" style={{ left: `${progress}%` }}></div>
                </div>
                <span className="w-8">3:42</span>
            </div>
          </div>

          {/* Right: Tools & Volume */}
          <div className="flex items-center justify-end w-[30%] gap-3 relative z-10">
            <button 
                onClick={onToggleVideo}
                className={`p-3 rounded-full transition-all duration-300 border border-transparent ${
                    isVideoMode 
                    ? 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/30 shadow-[0_0_15px_rgba(217,70,239,0.3)]' 
                    : 'bg-white/5 text-zinc-400 hover:text-white hover:border-white/10'
                }`}
                title="Toggle Immersive Video"
            >
                {isVideoMode ? <MonitorPlay className="w-6 h-6" /> : <Video className="w-6 h-6" />}
            </button>

             <button 
                className="p-3 rounded-full bg-white/5 text-zinc-400 hover:text-white hover:border-white/10 border border-transparent transition-all backdrop-blur-md"
                title="Queue"
            >
                <ListMusic className="w-6 h-6" />
            </button>

            <div className="w-px h-8 bg-white/10 mx-2" />

            <div className="flex items-center gap-3 group/vol">
              <button onClick={() => setVolume(v => v === 0 ? 75 : 0)}>
                  <Volume2 className={`w-6 h-6 transition-colors drop-shadow-md ${volume === 0 ? 'text-zinc-600' : 'text-zinc-400 hover:text-white'}`} />
              </button>
              <div className="w-24 h-1 bg-white/10 rounded-full overflow-hidden cursor-pointer relative">
                 <div className="h-full bg-zinc-400 group-hover/vol:bg-white transition-colors rounded-full" style={{ width: `${volume}%` }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PlayerBar;
