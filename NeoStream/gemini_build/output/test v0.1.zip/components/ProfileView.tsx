import React from 'react';
import { Settings, Share2, Edit2, LogOut, Heart, Play, Zap } from './Icon';
import { MOCK_SONGS, TRENDING_PLAYLISTS } from '../constants';

const ProfileView = () => {
  return (
    <div className="pb-48 animate-in fade-in duration-500 pt-0">
        {/* Cover Image */}
        <div className="h-64 md:h-80 w-full relative overflow-hidden group">
            <img 
                src="https://images.unsplash.com/photo-1535498730771-e735b998cd64?q=80&w=2568&auto=format&fit=crop" 
                alt="Cover" 
                className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/40 to-transparent" />
        </div>

        {/* Profile Header */}
        <div className="px-6 md:px-12 -mt-20 relative z-10 flex flex-col md:flex-row items-center md:items-end gap-6 mb-12 text-center md:text-left">
            {/* Avatar with Micro-Bounce Animation */}
            <div className="w-32 h-32 md:w-40 md:h-40 rounded-full p-1 bg-gradient-to-br from-indigo-500 to-fuchsia-500 shadow-2xl shrink-0 hover-micro-bounce cursor-pointer">
                <div className="w-full h-full rounded-full bg-[#09090b] overflow-hidden p-1">
                     <img 
                        src="https://i.pravatar.cc/150?img=33" 
                        alt="Profile" 
                        className="w-full h-full rounded-full object-cover"
                    />
                </div>
            </div>
            
            <div className="flex-1 mb-2 w-full flex flex-col items-center md:items-start">
                <h1 className="text-4xl md:text-5xl font-black font-syne text-white mb-1">Alex Cypher</h1>
                {/* Minimalist Sonic Explorer Badge with Float Animation */}
                <div className="flex items-center gap-2 mb-2 animate-float">
                    <span className="text-zinc-400 font-medium text-sm">@acypher</span>
                    <span className="text-zinc-600 text-xs">•</span>
                    <div className="flex items-center gap-1 text-[10px] font-bold tracking-widest uppercase text-fuchsia-400 opacity-90 bg-fuchsia-500/10 px-2 py-0.5 rounded-full border border-fuchsia-500/20">
                        <Zap className="w-3 h-3 fill-current" />
                        <span>Sonic Explorer</span>
                    </div>
                </div>

                <div className="flex items-center justify-center md:justify-start gap-4 mt-2 text-sm font-bold tracking-wide">
                    <span className="text-white">12.5k <span className="text-zinc-500 font-normal">Followers</span></span>
                    <span className="text-white">842 <span className="text-zinc-500 font-normal">Following</span></span>
                </div>
            </div>

            <div className="flex gap-3 w-full md:w-auto mt-4 md:mt-0 justify-center md:justify-start">
                <button className="px-6 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-medium transition-all flex items-center justify-center gap-2 backdrop-blur-md hover:scale-105 active:scale-95">
                    <Edit2 className="w-3.5 h-3.5" /> <span className="text-sm">Edit Profile</span>
                </button>
                <button className="p-2 rounded-full border border-white/10 hover:bg-white/10 transition-colors">
                    <Share2 className="w-4 h-4" />
                </button>
                <button className="p-2 rounded-full border border-white/10 hover:bg-white/10 transition-colors">
                    <Settings className="w-4 h-4" />
                </button>
            </div>
        </div>

        <div className="px-6 md:px-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left Column: Top Artists & Info */}
            <div className="space-y-8">
                <section>
                    <h3 className="text-xl font-bold font-syne mb-4 flex items-center gap-2">
                        <Heart className="w-5 h-5 text-fuchsia-500 fill-fuchsia-500" /> Top Artists
                    </h3>
                    {/* Overlapping Avatar Stack with specific z-indexing and enhanced overlap */}
                    <div className="flex -space-x-5 overflow-visible justify-center md:justify-start pl-2 py-2">
                        {[1,2,3,4].map((i, idx) => (
                             <div 
                                key={i} 
                                className="relative group cursor-pointer w-16 h-16 rounded-full border-4 border-[#09090b] overflow-hidden hover:scale-110 hover:z-50 transition-all duration-300 shadow-lg"
                                style={{ zIndex: 10 + idx, transform: `translateX(${idx * 2}px)` }} // Slight offset for visual stack effect
                             >
                                <img src={`https://i.pravatar.cc/150?img=${50+i}`} className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors"></div>
                             </div>
                        ))}
                         {/* The +4 Button - Stacked last on top */}
                         <div 
                            className="relative w-16 h-16 rounded-full border-4 border-[#09090b] flex items-center justify-center bg-zinc-800 text-zinc-400 font-bold hover:bg-zinc-700 hover:text-white transition-all cursor-pointer shadow-lg hover:scale-105 hover:z-50 hover:shadow-fuchsia-500/20"
                            style={{ zIndex: 20, transform: `translateX(8px)` }}
                         >
                            +4
                         </div>
                    </div>
                </section>

                <div className="p-6 rounded-2xl bg-white/5 border border-white/5 space-y-4">
                    <div className="flex justify-between items-center">
                        <span className="text-zinc-400">Subscription</span>
                        <span className="text-fuchsia-300 font-bold bg-fuchsia-500/10 px-2 py-1 rounded text-xs border border-fuchsia-500/20">PREMIUM</span>
                    </div>
                    <div className="w-full h-px bg-white/5" />
                    <div className="flex justify-between items-center">
                        <span className="text-zinc-400">Audio Quality</span>
                        <span className="text-white font-medium">Hi-Res Lossless</span>
                    </div>
                     <div className="w-full h-px bg-white/5" />
                    <button className="w-full py-2 text-red-400 hover:text-red-300 text-sm font-medium flex items-center justify-center gap-2">
                        <LogOut className="w-4 h-4" /> Sign Out
                    </button>
                </div>
            </div>

            {/* Right Column: Playlists & Activity */}
            <div className="lg:col-span-2 space-y-10">
                <section>
                    <h3 className="text-2xl font-bold font-syne mb-6">Public Playlists</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {TRENDING_PLAYLISTS.map(playlist => (
                            <div key={playlist.id} className="group cursor-pointer">
                                <div className="aspect-square rounded-xl overflow-hidden mb-3 relative">
                                    <img src={playlist.coverUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                        <Play className="w-8 h-8 fill-white text-white" />
                                    </div>
                                </div>
                                <h4 className="font-bold text-white truncate group-hover:text-fuchsia-400 transition-colors">{playlist.name}</h4>
                                <p className="text-xs text-zinc-500">{playlist.songs.length} tracks</p>
                            </div>
                        ))}
                         {/* Add New Playlist Placeholder */}
                         <div className="group cursor-pointer border border-dashed border-white/10 rounded-xl flex flex-col items-center justify-center aspect-square hover:bg-white/5 transition-colors">
                            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                                <span className="text-2xl text-zinc-400">+</span>
                            </div>
                            <span className="text-sm font-medium text-zinc-400">New Playlist</span>
                         </div>
                    </div>
                </section>
                
                 <section>
                    <h3 className="text-2xl font-bold font-syne mb-6">Recently Played</h3>
                     <div className="space-y-2">
                        {MOCK_SONGS.slice(0, 4).map((song, i) => (
                            <div key={song.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-colors group cursor-pointer">
                                <span className="text-zinc-600 font-mono w-4 text-center">{i + 1}</span>
                                <img src={song.coverUrl} className="w-10 h-10 rounded object-cover" />
                                <div className="flex-1">
                                    <h4 className="font-medium text-white group-hover:text-fuchsia-400 transition-colors">{song.title}</h4>
                                    <p className="text-xs text-zinc-500">{song.artist}</p>
                                </div>
                                <span className="text-xs text-zinc-600">{song.duration}</span>
                                <Heart className="w-4 h-4 text-zinc-600 hover:text-fuchsia-500 cursor-pointer" />
                            </div>
                        ))}
                     </div>
                </section>
            </div>
        </div>
    </div>
  );
};

export default ProfileView;