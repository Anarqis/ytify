
import React from 'react';
import { Home, Search, Library, Sparkles, Heart, User, PanelLeftClose, PanelLeftOpen } from './Icon';
import { ViewMode } from '../types';
import { Logo } from './Logo';

interface SidebarProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  collapsed: boolean;
  toggleCollapsed: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange, collapsed, toggleCollapsed }) => {
  
  const NavItem = ({ view, icon: Icon, label, isAi = false }: { view: ViewMode, icon: any, label: string, isAi?: boolean }) => (
    <button
      onClick={() => onViewChange(view)}
      className={`flex items-center w-full px-3 py-3 rounded-xl transition-all duration-300 ease-in-out group relative overflow-hidden mb-1
        ${currentView === view 
          ? (isAi ? 'bg-gradient-to-r from-fuchsia-600/10 to-purple-600/10 text-white border border-fuchsia-500/20' : 'bg-white/10 text-white shadow-[inset_0_1px_0_0_rgba(255,255,255,0.1)]') 
          : 'text-zinc-400 hover:text-white hover:bg-white/5'
        } 
        ${collapsed ? 'justify-center gap-0' : 'justify-start gap-4'}
      `}
      title={collapsed ? label : undefined}
    >
      <Icon className={`w-5 h-5 shrink-0 transition-colors duration-300 ${isAi && currentView === view ? 'text-fuchsia-400' : ''}`} />
      
      <span 
        className={`font-medium tracking-wide whitespace-nowrap overflow-hidden transition-all ease-in-out
        ${collapsed 
            ? 'w-0 opacity-0 duration-200' 
            : 'w-auto opacity-100 duration-500 delay-200' 
        }`}
      >
        {label}
      </span>

      {isAi && (
        <span 
            className={`text-[8px] font-bold uppercase tracking-widest px-1.5 py-[2px] rounded border transition-all ease-in-out overflow-hidden
            ${currentView === view 
                ? 'bg-fuchsia-500/10 text-fuchsia-300/80 border-fuchsia-500/20' 
                : 'bg-white/5 text-zinc-600 border-white/5 group-hover:text-zinc-500 group-hover:border-white/10'
            }
            ${collapsed 
                ? 'w-0 opacity-0 px-0 border-0 duration-200' 
                : 'ml-auto w-auto opacity-100 duration-500 delay-200'
            }`}
        >
          Beta
        </span>
      )}
    </button>
  );

  return (
    // Changed border color to border-white/10 for better definition against dark backgrounds
    <div 
      className={`hidden lg:flex flex-col h-full bg-[#09090b] border-r border-white/10 pt-8 pb-40 shrink-0 relative z-50 transition-[width,padding] duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]
      ${collapsed 
        ? 'w-20 px-2' 
        : 'w-64 px-6' 
      }`}
    >
      {/* Branding Area - Toujours visible avec effet de lueur stabilisé */}
      <div className={`flex items-center mb-10 h-14 transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] ${collapsed ? 'justify-center' : 'justify-start gap-4'}`}>
        <div className="relative shrink-0 transition-all duration-500 w-11 h-11 group cursor-pointer">
             <div className="absolute inset-0 bg-fuchsia-600 blur-2xl opacity-40 group-hover:opacity-60 transition-opacity animate-pulse"></div>
             <div className="relative z-10 w-full h-full bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 group-hover:scale-110 transition-transform">
                <Logo className="w-8 h-8 drop-shadow-lg" />
             </div>
        </div>
        
        <div className={`overflow-hidden flex flex-col justify-center transition-all ease-in-out
            ${collapsed 
                ? 'w-0 opacity-0 duration-200' 
                : 'w-40 opacity-100 duration-500 delay-200'
            }`}
        >
            <h1 className="text-2xl font-black tracking-tighter text-white font-syne whitespace-nowrap drop-shadow-2xl">
                NEOSTREAM
            </h1>
            <div className="h-0.5 w-10 bg-gradient-to-r from-fuchsia-500 to-transparent mt-0.5 rounded-full" />
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto scrollbar-hide flex flex-col">
        <div className={`overflow-hidden transition-all ease-in-out ${collapsed ? 'h-0 opacity-0 duration-200' : 'h-auto opacity-100 mb-2 duration-500 delay-200'}`}>
             <p className="px-4 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] whitespace-nowrap mb-2">Discover</p>
        </div>
        
        {collapsed && <div className="h-4" />}
        
        <NavItem view={ViewMode.HOME} icon={Home} label="Home" />
        <NavItem view={ViewMode.SEARCH} icon={Search} label="Search" />
        <NavItem view={ViewMode.LIBRARY} icon={Library} label="Library" />
        
        <div className="mt-8 mb-2">
           <div className={`overflow-hidden transition-all ease-in-out ${collapsed ? 'h-0 opacity-0 duration-200' : 'h-auto opacity-100 mb-2 duration-500 delay-200'}`}>
              <p className="px-4 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] whitespace-nowrap mb-2">Intelligence</p>
           </div>
          <NavItem view={ViewMode.AI_DJ} icon={Sparkles} label="Synesthesia" isAi />
        </div>

        <div className="mt-8 mb-2">
            <div className={`overflow-hidden transition-all ease-in-out ${collapsed ? 'h-0 opacity-0 duration-200' : 'h-auto opacity-100 mb-2 duration-500 delay-200'}`}>
                <p className="px-4 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] whitespace-nowrap mb-2">Collection</p>
            </div>
            
            <button 
                onClick={() => onViewChange(ViewMode.LIKED_SONGS)}
                className={`flex items-center w-full px-3 py-3 rounded-xl transition-all duration-300 ease-in-out group relative overflow-hidden mb-1
                    ${currentView === ViewMode.LIKED_SONGS
                      ? 'bg-white/10 text-white shadow-[inset_0_1px_0_0_rgba(255,255,255,0.1)]' 
                      : 'text-zinc-400 hover:text-white hover:bg-white/5'
                    } ${collapsed ? 'justify-center gap-0' : 'justify-start gap-4'}`}
                title={collapsed ? "Liked Songs" : undefined}
            >
                <div className="w-5 h-5 bg-gradient-to-br from-red-500 to-orange-600 rounded flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform shrink-0">
                    <Heart className="w-3 h-3 text-white fill-white" />
                </div>
                <span 
                    className={`font-medium truncate transition-all ease-in-out overflow-hidden
                    ${collapsed 
                        ? 'w-0 opacity-0 duration-200' 
                        : 'w-auto opacity-100 duration-500 delay-200'
                    }`}
                >
                    Liked Songs
                </span>
            </button>
        </div>

        <div className="mt-8 mb-2">
             <div className={`overflow-hidden transition-all ease-in-out ${collapsed ? 'h-0 opacity-0 duration-200' : 'h-auto opacity-100 mb-2 duration-500 delay-200'}`}>
                <p className="px-4 text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] whitespace-nowrap mb-2">Personal</p>
             </div>
             <NavItem view={ViewMode.PROFILE} icon={User} label="Profile" />
        </div>

        <div className="mt-auto pt-6 flex justify-center overflow-hidden">
            <button 
                onClick={toggleCollapsed}
                className={`flex items-center justify-center rounded-lg transition-all duration-300 hover:bg-white/10 group whitespace-nowrap overflow-hidden relative
                ${collapsed ? 'w-10 h-10' : 'w-full py-3 bg-white/5 border border-white/5 gap-2'}`}
                title={collapsed ? "Expand Sidebar" : "Collapse Sidebar"}
            >
                <div className="relative w-5 h-5 flex items-center justify-center shrink-0">
                     <PanelLeftOpen className={`absolute w-full h-full text-zinc-400 group-hover:text-white transition-all duration-300 ${collapsed ? 'opacity-100 scale-100 rotate-0' : 'opacity-0 scale-75 -rotate-90'}`} />
                     <PanelLeftClose className={`absolute w-full h-full text-zinc-400 group-hover:text-white transition-all duration-300 ${collapsed ? 'opacity-0 scale-75 rotate-90' : 'opacity-100 scale-100 rotate-0'}`} />
                </div>
                
                <span className={`text-xs font-bold text-zinc-400 group-hover:text-white uppercase tracking-wider transition-all duration-300 ${collapsed ? 'w-0 opacity-0' : 'w-auto opacity-100'}`}>
                    Réduire
                </span>
            </button>
        </div>
      </nav>
    </div>
  );
};

export default Sidebar;
