
import React from 'react';
import { Home, Search, Library, Sparkles, User } from './Icon';
import { ViewMode } from '../types';

interface MobileNavProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
}

const MobileNav: React.FC<MobileNavProps> = ({ currentView, onViewChange }) => {
  const NavItem = ({ view, icon: Icon }: { view: ViewMode, icon: any }) => {
    const isActive = currentView === view;
    return (
      <button
        onClick={() => onViewChange(view)}
        className={`flex items-center justify-center w-full h-full relative group
          ${isActive ? 'text-white' : 'text-zinc-500'}`}
      >
        <div className={`relative transition-all duration-300 ${isActive ? 'scale-110' : 'scale-100'}`}>
             <Icon className={`w-6 h-6 landscape:w-5 landscape:h-5 ${isActive ? 'fill-white/10 text-white' : ''}`} />
             {isActive && (
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1 h-1 bg-fuchsia-500 rounded-full shadow-[0_0_8px_#d946ef]"></div>
             )}
        </div>
      </button>
    );
  };

  return (
    // Changed md:hidden to lg:hidden
    <div className="fixed bottom-0 left-0 right-0 h-[64px] landscape:h-[48px] bg-[#09090b]/95 backdrop-blur-xl border-t border-white/5 z-[60] lg:hidden flex items-center justify-around px-2 safe-area-pb">
      <NavItem view={ViewMode.HOME} icon={Home} />
      <NavItem view={ViewMode.SEARCH} icon={Search} />
      <NavItem view={ViewMode.AI_DJ} icon={Sparkles} />
      <NavItem view={ViewMode.LIBRARY} icon={Library} />
      <NavItem view={ViewMode.PROFILE} icon={User} />
    </div>
  );
};

export default MobileNav;
