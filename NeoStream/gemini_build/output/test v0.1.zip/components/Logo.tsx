import React from 'react';

export const Logo = ({ className = "w-8 h-8" }: { className?: string }) => (
  <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={`${className} overflow-visible`}>
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#e0c3fc" />
        <stop offset="100%" stopColor="#8ec5fc" />
      </linearGradient>
    </defs>
    
    {/* Inner Spiral 'N' - Static and Clean */}
    <g>
        <path 
            d="M30 70 C 25 60, 25 35, 35 25 C 45 15, 65 15, 75 25 C 90 40, 90 60, 75 75 C 65 85, 45 85, 35 75 Z" 
            stroke="url(#logoGradient)" 
            strokeWidth="6" 
            strokeLinecap="round"
            className="opacity-40"
        />
        <path 
            d="M38 68 C 32 58, 32 40, 38 32 C 45 24, 60 24, 68 32 C 80 44, 80 58, 68 68" 
            stroke="white" 
            strokeWidth="6" 
            strokeLinecap="round"
        />
        {/* Central Core */}
        <circle cx="53" cy="53" r="6" fill="white" />
    </g>
  </svg>
);