
import React from 'react';
import { Song, PlaybackState } from '../types';
import { MOCK_SONGS } from '../constants';
import { Minimize2, Play, PanelLeftOpen, PanelLeftClose, Clock } from './Icon';

interface VideoOverlayProps {
  song: Song;
  playbackState: PlaybackState;
  isActive: boolean;
  onClose: () => void;
  onPlayRecommend: (song: Song) => void;
  isPanelOpen: boolean;
  setIsPanelOpen: (isOpen: boolean) => void;
  isSidebarCollapsed: boolean;
}

const VideoOverlay: React.FC<VideoOverlayProps> = ({ 
    song, 
    playbackState, 
    isActive, 
    onClose, 
    onPlayRecommend,
    isPanelOpen,
    setIsPanelOpen,
    isSidebarCollapsed
}) => {
  if (!isActive) return null;

  // Filter out current song from recommendations
  const recommendations = MOCK_SONGS.filter(s => s.id !== song.id).slice(0, 5);

  return (
    <div 
        className={`fixed top-0 bottom-0 right-0 z-[60] bg-black animate-in fade-in duration-500 block overflow-hidden transition-[left] duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]
        ${isSidebarCollapsed ? 'left-0 lg:left-20' : 'left-0 lg:left-64'}`}
    >
        
        {/* Main Video Area - Absolute Full Screen */}
        <div className="absolute inset-0 z-10 bg-black">
            {/* Header Overlay Controls */}
            <div className="absolute top-0 left-0 right-0 p-6 z-50 flex justify-between items-start pointer-events-none h-32 bg-gradient-to-b from-black/80 via-black/20 to-transparent">
                 
                 {/* Left Control - Sidebar Toggle */}
                 <div className="pointer-events-auto transition-all duration-700 ease-[cubic-bezier(0.25,0.8,0.25,1)]" style={{ transform: isPanelOpen ? 'translateX(360px)' : 'translateX(0)' }}>
                    <button 
                        onClick={() => setIsPanelOpen(!isPanelOpen)}
                        className={`flex items-center justify-center gap-2 px-4 py-2 rounded-full transition-all backdrop-blur-md border shadow-lg group
                        ${isPanelOpen 
                            ? 'bg-black/40 text-white border-white/10 hover:bg-black/60' 
                            : 'bg-black/20 hover:bg-white/10 text-white border-white/10'}`}
                    >
                        {isPanelOpen ? <PanelLeftClose className="w-4 h-4" /> : <PanelLeftOpen className="w-4 h-4" />}
                        <span className="text-[10px] font-bold uppercase tracking-wider">{isPanelOpen ? 'Close' : 'Up Next'}</span>
                    </button>
                 </div>

                 {/* Right Control - Minimize */}
                 <div className="pointer-events-auto">
                    <button 
                        onClick={onClose}
                        className="flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-black/20 hover:bg-white/10 text-zinc-300 hover:text-white transition-all backdrop-blur-md border border-white/5 hover:border-white/20 group"
                    >
                        <Minimize2 className="w-4 h-4" />
                        <span className="text-[10px] font-bold uppercase tracking-wider hidden group-hover:inline-block animate-in fade-in slide-in-from-right-2">Close Mode</span>
                    </button>
                 </div>
            </div>

            {/* Video Content */}
            <div className="w-full h-full relative flex items-center justify-center overflow-hidden">
                <div 
                    className={`w-full h-full bg-cover bg-center transition-transform duration-[30s] ease-linear ${playbackState === PlaybackState.PLAYING ? 'scale-110' : 'scale-100'}`}
                    style={{ backgroundImage: `url(${song.coverUrl})`, opacity: 0.7 }}
                />
                 {/* Play State Overlay */}
                 {playbackState === PlaybackState.PAUSED && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm transition-all duration-300 z-20">
                        <div className="w-24 h-24 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-[0_0_50px_rgba(255,255,255,0.1)] hover:scale-110 transition-transform cursor-pointer">
                             <Play className="w-10 h-10 fill-white text-white ml-1.5" />
                        </div>
                    </div>
                )}
            </div>
            
            {/* Bottom Gradient for Player Visibility */}
            <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-black via-black/80 to-transparent pointer-events-none z-20"></div>
        </div>

        {/* Sidebar / Bottom Sheet for Recommendations - Overlay */}
        <div 
            className={`absolute top-0 bottom-0 left-0 z-30 flex flex-col overflow-hidden transition-all duration-700 ease-[cubic-bezier(0.25,0.8,0.25,1)]
            ${isPanelOpen 
                ? 'w-[350px] translate-x-0' 
                : 'w-[350px] -translate-x-full'
            }`}
        >
            {/* Transparent Glass Background - Now with smooth opacity transition */}
            <div 
                className={`absolute inset-0 bg-[#09090b]/40 backdrop-blur-2xl border-r border-white/5 transition-opacity duration-700 ease-in-out
                ${isPanelOpen ? 'opacity-100' : 'opacity-0'}`} 
            />
            
            <div className={`relative z-10 p-0 lg:pl-8 lg:pr-4 h-full overflow-y-auto min-w-[320px] scrollbar-hide pt-32 pb-48 transition-all duration-500 delay-100 ${isPanelOpen ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
                <div className="px-4 lg:px-0 mb-8">
                    <h3 className="text-4xl font-black font-syne mb-2 text-white drop-shadow-xl leading-none">What's<br/>Next</h3>
                    <p className="text-sm text-zinc-300 font-medium">Playing from {song.album}</p>
                </div>
                
                <div className="space-y-3 px-2 lg:px-0">
                    {recommendations.map((rec) => (
                        <div 
                            key={rec.id} 
                            onClick={() => onPlayRecommend(rec)}
                            className="flex items-center gap-4 p-3 rounded-2xl hover:bg-white/10 cursor-pointer group transition-all duration-300 border border-transparent hover:border-white/10 active:scale-95"
                        >
                            {/* Thumbnail */}
                            <div className="relative w-16 h-16 rounded-xl overflow-hidden shrink-0 shadow-lg border border-white/5 group-hover:border-white/30 transition-all">
                                <img src={rec.coverUrl} className="w-full h-full object-cover opacity-90 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" />
                                <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Play className="w-4 h-4 fill-white" />
                                </div>
                            </div>

                            <div className="flex-1 min-w-0 flex flex-col justify-center h-full">
                                <h4 className="font-bold text-base text-zinc-100 truncate group-hover:text-fuchsia-400 transition-colors font-syne leading-tight mb-1">{rec.title}</h4>
                                <p className="text-xs text-zinc-400 truncate font-medium">
                                    {rec.artist}
                                </p>
                            </div>
                            
                            <span className="text-xs font-mono text-zinc-500">{rec.duration}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>

    </div>
  );
};

export default VideoOverlay;
