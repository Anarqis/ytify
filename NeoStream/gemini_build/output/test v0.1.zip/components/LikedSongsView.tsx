
import React, { useState } from 'react';
import { Heart, Play, MoreHorizontal, LayoutGrid, List as ListIcon, Zap } from './Icon';
import { MOCK_SONGS } from '../constants';
import { Song } from '../types';

interface LikedSongsViewProps {
  onPlaySong: (song: Song) => void;
  currentSongId?: string;
}

const LikedSongsView: React.FC<LikedSongsViewProps> = ({ onPlaySong, currentSongId }) => {
  const [viewFormat, setViewFormat] = useState<'grid' | 'list'>('grid');
  // Generate more songs for the mosaic effect
  const likedSongs = [...MOCK_SONGS, ...MOCK_SONGS, ...MOCK_SONGS, ...MOCK_SONGS].map((s, i) => ({ ...s, id: `liked-${s.id}-${i}` }));

  return (
    <div className="h-full flex flex-col animate-in fade-in duration-700 pb-20 relative pt-12 md:pt-16">
       {/* Ambient Background */}
       <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-900/40 via-[#09090b] to-[#09090b] pointer-events-none" />

       {/* Header Section - Moved back up to remove empty space */}
       <div className="px-8 md:px-12 pt-12 md:pt-16 pb-8 flex flex-col md:flex-row md:items-end justify-between gap-6 relative z-10">
          <div>
              <div className="flex items-center gap-2 mb-2">
                 <span className="w-2 h-2 rounded-full bg-fuchsia-500 animate-pulse" />
                 <span className="text-[10px] font-black tracking-[0.3em] text-fuchsia-400 uppercase">Personal Collection</span>
              </div>
              <h1 className="text-5xl md:text-8xl font-black font-syne text-white leading-tight tracking-tighter drop-shadow-2xl">
                Sonic Vault
              </h1>
              <p className="text-zinc-400 mt-3 max-w-md text-sm md:text-base font-medium">
                Your curated artifacts. <span className="text-white">{likedSongs.length} tracks</span> saved in the neural network.
              </p>
          </div>

          <div className="flex items-center gap-4 bg-white/5 p-2 rounded-full backdrop-blur-md border border-white/10 shadow-2xl">
              <button 
                onClick={() => setViewFormat('grid')}
                className={`p-2.5 rounded-full transition-all ${viewFormat === 'grid' ? 'bg-white text-black shadow-lg scale-110' : 'text-zinc-400 hover:text-white'}`}
              >
                  <LayoutGrid className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setViewFormat('list')}
                className={`p-2.5 rounded-full transition-all ${viewFormat === 'list' ? 'bg-white text-black shadow-lg scale-110' : 'text-zinc-400 hover:text-white'}`}
              >
                  <ListIcon className="w-5 h-5" />
              </button>
              <div className="w-px h-8 bg-white/10 mx-1" />
              <button 
                 onClick={() => onPlaySong(likedSongs[0])}
                 className="px-8 py-3 rounded-full bg-gradient-to-r from-indigo-500 to-fuchsia-600 text-white font-black text-sm uppercase tracking-widest flex items-center gap-2 hover:scale-105 active:scale-95 transition-all shadow-[0_0_25px_rgba(139,92,246,0.4)]"
              >
                 <Zap className="w-4 h-4 fill-white" /> Shuffle
              </button>
          </div>
       </div>

       {/* Mosaic Content - Adjusted padding to remove the large "black block" */}
       <div className="flex-1 overflow-y-auto px-8 md:px-12 scrollbar-none z-10 pb-40">
          {viewFormat === 'grid' ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {likedSongs.map((song, idx) => (
                    <div 
                        key={song.id}
                        onClick={() => onPlaySong(song)}
                        className={`group relative aspect-[3/4] rounded-2xl overflow-hidden cursor-pointer transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_20px_40px_-10px_rgba(0,0,0,0.5)] border border-white/5 ${currentSongId === song.id ? 'ring-2 ring-fuchsia-500' : ''}`}
                    >
                        <img src={song.coverUrl} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale-[30%] group-hover:grayscale-0" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />
                        
                        <div className="absolute inset-0 p-5 flex flex-col justify-end transform transition-transform duration-300">
                             <div className="flex justify-between items-end">
                                 <div className="min-w-0 flex-1">
                                     <h3 className="font-bold text-lg leading-tight text-white mb-1 truncate font-syne">{song.title}</h3>
                                     <p className="text-xs font-medium text-fuchsia-300 uppercase tracking-wider truncate">{song.artist}</p>
                                 </div>
                                 <button className="w-11 h-11 rounded-full bg-white text-black flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-300 shadow-xl hover:scale-110">
                                     <Play className="w-4 h-4 fill-current ml-0.5" />
                                 </button>
                             </div>
                        </div>
                        
                        <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                             <Heart className="w-5 h-5 text-fuchsia-500 fill-fuchsia-500 drop-shadow-lg" />
                        </div>
                    </div>
                ))}
            </div>
          ) : (
            <div className="space-y-3">
                 {likedSongs.map((song, idx) => (
                    <div 
                        key={song.id}
                        onClick={() => onPlaySong(song)}
                        className={`group flex items-center gap-6 p-4 rounded-2xl transition-all duration-300 border border-transparent hover:border-white/10 hover:bg-white/5 cursor-pointer ${currentSongId === song.id ? 'bg-white/10 border-fuchsia-500/30' : ''}`}
                    >
                        <span className="font-mono text-zinc-600 w-8 text-center text-sm group-hover:text-white transition-colors">{idx + 1}</span>
                        <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 relative shadow-lg">
                             <img src={song.coverUrl} className="w-full h-full object-cover" />
                             <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                 <Play className="w-6 h-6 fill-white" />
                             </div>
                        </div>
                        <div className="flex-1 min-w-0">
                             <h4 className={`font-bold text-xl ${currentSongId === song.id ? 'text-fuchsia-400' : 'text-white'} font-syne`}>{song.title}</h4>
                             <p className="text-sm text-zinc-500 font-medium">{song.artist}</p>
                        </div>
                        <div className="hidden lg:block text-sm text-zinc-500 font-syne uppercase tracking-wider">{song.album}</div>
                        <div className="text-sm text-zinc-500 font-mono">{song.duration}</div>
                        <button className="opacity-0 group-hover:opacity-100 transition-opacity p-2 hover:text-white">
                            <MoreHorizontal className="w-6 h-6" />
                        </button>
                    </div>
                 ))}
            </div>
          )}
       </div>
    </div>
  );
};

export default LikedSongsView;
