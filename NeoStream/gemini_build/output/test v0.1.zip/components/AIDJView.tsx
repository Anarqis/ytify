
import React, { useState } from 'react';
import { Sparkles, Fingerprint, Search, Play } from './Icon';
import { getMusicRecommendation } from '../services/geminiService';

const AIDJView: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAskDJ = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setLoading(true);
    setResponse(null);
    const result = await getMusicRecommendation(prompt);
    setResponse(result);
    setLoading(false);
  };

  return (
    <div className="p-8 w-full max-w-5xl mx-auto flex flex-col items-center min-h-[70vh] pt-32 md:pt-40 animate-in fade-in duration-700">
      <div className="text-center mb-12">
        <div className="relative w-24 h-24 mx-auto mb-8 flex items-center justify-center group">
             <div className="absolute inset-0 bg-fuchsia-500 blur-3xl opacity-40 animate-pulse group-hover:opacity-60 transition-opacity"></div>
             <div className="relative w-full h-full bg-gradient-to-tr from-fuchsia-600 to-indigo-600 rounded-[2rem] flex items-center justify-center shadow-2xl border border-white/10 group-hover:scale-105 transition-transform duration-500">
                 <Fingerprint className="w-12 h-12 text-white" />
             </div>
        </div>
        <h2 className="text-5xl md:text-7xl font-black mb-6 text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-zinc-400 font-syne tracking-tighter drop-shadow-lg">
            Sonic Synesthesia™
        </h2>
        <p className="text-zinc-400 text-xl max-w-2xl mx-auto leading-relaxed font-light">
            Upload a memory, a color, or a dream. Our neural engine reconstructs the audio frequencies that match your subconscious.
        </p>
      </div>

      <form onSubmit={handleAskDJ} className="w-full max-w-4xl relative mb-16 group z-20">
        {/* Glow Effect */}
        <div className="absolute -inset-1 bg-gradient-to-r from-fuchsia-500 via-indigo-500 to-cyan-500 rounded-full blur-xl opacity-20 group-hover:opacity-50 group-focus-within:opacity-60 transition-all duration-700"></div>
        
        <div className="relative flex items-center">
            <input 
                type="text" 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Search for tracks..."
                className="w-full bg-white text-black border-2 border-transparent focus:border-white/50 rounded-full py-6 pl-16 pr-40 text-2xl font-bold placeholder-zinc-400 focus:outline-none shadow-[0_0_50px_rgba(255,255,255,0.1)] transition-all font-syne"
            />
            <div className="absolute left-6 text-zinc-400">
                <Search className="w-8 h-8" />
            </div>
            
            <div className="absolute right-3 top-3 bottom-3">
                 <button 
                    type="submit"
                    disabled={loading || !prompt}
                    className="h-full bg-black text-white font-bold px-8 rounded-full hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed tracking-wide shadow-lg flex items-center gap-2"
                >
                    {loading ? (
                        <span className="flex items-center gap-2"><Sparkles className="w-4 h-4 animate-spin" /> Thinking</span>
                    ) : (
                        <span>Generate</span>
                    )}
                </button>
            </div>
        </div>
      </form>

      {response && (
        <div className="w-full max-w-3xl glass-panel-heavy p-10 rounded-[2.5rem] animate-in slide-in-from-bottom-10 duration-700 border border-white/10 relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
                <Sparkles className="w-40 h-40 text-white" />
            </div>
            
            <div className="flex items-center gap-3 mb-6">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_#10b981]"></div>
                <h3 className="text-emerald-400 font-bold uppercase tracking-[0.2em] text-xs">
                    Analysis Complete
                </h3>
            </div>
            
            <p className="text-xl md:text-2xl leading-relaxed text-zinc-200 whitespace-pre-wrap relative z-10 font-medium font-syne">
                {response}
            </p>
            
            <div className="mt-10 flex gap-4 relative z-10">
                <button className="px-8 py-4 bg-white text-black hover:bg-zinc-200 rounded-full text-base font-bold transition-colors flex items-center gap-2 shadow-[0_0_20px_rgba(255,255,255,0.3)] hover:scale-105 active:scale-95">
                    <Play className="w-5 h-5 fill-current" /> Start Stream
                </button>
                <button className="px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-base font-bold transition-colors">
                    Save to Collection
                </button>
            </div>
        </div>
      )}
    </div>
  );
};

export default AIDJView;
