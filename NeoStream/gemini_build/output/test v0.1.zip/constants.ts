
import { Song, Playlist } from './types';

export const MOCK_SONGS: Song[] = [
  {
    id: '1',
    title: 'Neon Nights',
    artist: 'Cyber Collective',
    album: 'Future City',
    coverUrl: 'https://picsum.photos/400/400?random=1',
    duration: '3:42',
    genre: 'Synthwave',
    views: '1.2M',
    publishedAt: '2 days ago'
  },
  {
    id: '2',
    title: 'Midnight Drive',
    artist: 'The Nightloop',
    album: 'Velvet Sky',
    coverUrl: 'https://picsum.photos/400/400?random=2',
    duration: '4:15',
    genre: 'Lo-Fi',
    views: '845K',
    publishedAt: '1 week ago'
  },
  {
    id: '3',
    title: 'Digital Rain',
    artist: 'Glitch Protocol',
    album: 'System Failure',
    coverUrl: 'https://picsum.photos/400/400?random=3',
    duration: '2:58',
    genre: 'Electronic',
    views: '2.4M',
    publishedAt: '3 days ago'
  },
  {
    id: '4',
    title: 'Solar Flare',
    artist: 'Star Dust',
    album: 'Cosmos',
    coverUrl: 'https://picsum.photos/400/400?random=4',
    duration: '3:22',
    genre: 'Pop',
    views: '5.1M',
    publishedAt: '1 month ago'
  },
  {
    id: '5',
    title: 'Urban Jungle',
    artist: 'Concrete Beats',
    album: 'Metropolis',
    coverUrl: 'https://picsum.photos/400/400?random=5',
    duration: '3:10',
    genre: 'Hip Hop',
    views: '320K',
    publishedAt: '5 hours ago'
  },
  {
    id: '6',
    title: 'Deep Ocean',
    artist: 'Blue Hz',
    album: 'Frequencies',
    coverUrl: 'https://picsum.photos/400/400?random=6',
    duration: '5:45',
    genre: 'Ambient',
    views: '92K',
    publishedAt: 'Just now'
  }
];

export const TRENDING_PLAYLISTS: Playlist[] = [
  {
    id: 'p1',
    name: 'Top 50 Global',
    description: 'The most played tracks right now.',
    coverUrl: 'https://picsum.photos/400/400?random=10',
    songs: MOCK_SONGS.slice(0, 4)
  },
  {
    id: 'p2',
    name: 'Cyberpunk Focus',
    description: 'High tempo beats for coding.',
    coverUrl: 'https://picsum.photos/400/400?random=11',
    songs: MOCK_SONGS.slice(2, 6)
  },
  {
    id: 'p3',
    name: 'Chill Sunday',
    description: 'Relax and unwind.',
    coverUrl: 'https://picsum.photos/400/400?random=12',
    songs: [MOCK_SONGS[1], MOCK_SONGS[5], MOCK_SONGS[0]]
  }
];
