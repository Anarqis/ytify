
export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  coverUrl: string;
  duration: string; // Display format "3:45"
  videoUrl?: string; // Mock URL for video context
  genre: string;
  views?: string;
  publishedAt?: string;
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  coverUrl: string;
  songs: Song[];
}

export enum ViewMode {
  HOME = 'HOME',
  SEARCH = 'SEARCH',
  LIBRARY = 'LIBRARY',
  AI_DJ = 'AI_DJ',
  PROFILE = 'PROFILE',
  LIKED_SONGS = 'LIKED_SONGS'
}

export enum PlaybackState {
  PLAYING = 'PLAYING',
  PAUSED = 'PAUSED',
  IDLE = 'IDLE'
}

export interface AIMessage {
  role: 'user' | 'model';
  text: string;
}
