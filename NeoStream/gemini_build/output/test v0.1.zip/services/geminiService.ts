
import { GoogleGenAI } from "@google/genai";

// Safe access to API KEY to prevent top-level crashes
const getApiKey = () => {
  try {
    return process.env.API_KEY || "";
  } catch (e) {
    return "";
  }
};

export const getMusicRecommendation = async (prompt: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are an avant-garde AI DJ for a futuristic music platform called NeoStream. 
      The user wants music matching this vibe: "${prompt}".
      
      Respond with a short, cool, enthusiastic paragraph describing the perfect playlist for them. 
      Suggest 3 specific (real or fictional) genres and a "Vibe Score" (0-100%).
      Keep it under 100 words. Be stylish and energetic.`,
    });
    
    return response.text || "Could not generate a recommendation at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to the neural network. Try again later.";
  }
};
